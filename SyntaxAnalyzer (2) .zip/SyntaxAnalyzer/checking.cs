﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.IO;

namespace SyntaxAnalyzer
{
	public class Tokens
	{
		string ClassPart;
		string ValuePart;
		int line_no;
	}
	public class Checking : Tokenizing
	{

		static IDictionary<string, string> keyword_list = new Dictionary<string, string>(){
				{"int","dt"},
				{"float","dt"},
				{"bool","dt"},
				{"str","dt"},
				{"char","dt"},
				{"main","main"},
				{"public","access-modifier"},
				{"private","access-modifier"},
				{"protected","access-modifier"},
				{"static","static"},
				{"abstract","abstract"},
				{"sealed","sealed"},
				{"class","class"},

				{"void","void"},
				{"while","while"},
				{"if","if"},
				{"else","else"},
				{"for","for"},
				{"do","do"},
				{"break","break"},
				{"continue","continue" },
				{"return","return" },
				{"struct","struct" },
				{"new","new"},
				{"func","func"},
				 {"and","and"},
				 {"or","or"},
				 {"not","not"},
				 {"nl","newline" }

	};


		static List<string> Inc_Dec = new List<string> { "++", "--" };
		static List<string> MD = new List<string> { "*", "/" };
		static List<string> PM = new List<string> { "+", "-" };
		static List<string> RO = new List<string> { "<", ">", "<=", ">=", "==", "!=" };
		static List<string> comp_assign = new List<string> { "+=", "-=", "*=", "/=" };
		static List<string> assign = new List<string> { "=" };

		static Regex re_id = new Regex(@"^@?[A-Za-z]+_*[A-Za-z\d]+|[A-Za-z]*$");  //id

		static Regex re_int = new Regex(@"^[+-]?\d+$"); //integer constant

		static Regex re_flt = new Regex(@"^[+-]?\d*.\d+$"); //float constant

		static Regex re_char = new Regex(@"^\'(\\[\'\\\""bfnrt0]|\w|[!-/:-@[-`{-~])\'$"); //char constant

		static Regex re_str = new Regex(@"^""(\\[\'\\\""bfnrt0]|\w\s*|[!-/:-@[-`{-~]\s*)*""$"); //string constant

		public static List<Tuple<string, string, int>> tokens = new List<Tuple<string, string, int>>();


		static void Main(string[] args)
		{

			string inputtext = File.ReadAllText(@"C:\Users\HP\Desktop\houra\source.txt");

			break_words(inputtext);


			Lexical_Analyzer();
			tokens.Add(new Tuple<string, string, int>("$", "", -1));
			// cp        vp      line
			//	List<Tokens> token = new List<Tokens>();
			//		token = Lexical_Analyzer();
			//	Tokens temp = new Tokens;
			//		temp.ClassPart = "$";
			//	token.Add(temp);

			new SyntaxAnalyzer(tokens);

		}

		public static void Lexical_Analyzer()
		{


			String word = "";
			int line_no = 0;
			String Class_pt = "";


			foreach (var item in mylist)
			{  // item1 --->> line_no    item2 ---->> word

				word = item.Item2;
				line_no = item.Item1;

				char ch = word[0];



				if (ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z')
				{

					if (check_id(word))
					{

						Class_pt = check_kw(word);
						if (Class_pt == null)
						{

							Class_pt = "ID";


							tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));
						}
						else if (Class_pt == word)
						{


							tokens.Add(new Tuple<string, string, int>(Class_pt, " ", line_no));
						}

						else
						{

							tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));
						}
					}

					else

					{


						tokens.Add(new Tuple<string, string, int>("invalid token", word, line_no));


					}
				}

				else if (ch == '@')
				{

					if (check_id(word))
					{

						Class_pt = "ID";
						tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));

					}
					else

					{

						tokens.Add(new Tuple<string, string, int>("invalid token", word, line_no));

					}

				}

				else if (ch == '\"')
				{

					if (check_str(word))
					{
						string temp = "";

						Class_pt = "str_const";
						for (int i = 1; i < word.Length - 1; i++) { temp = temp + word[i]; }
						word = temp;
						tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));

					}
					else
					{

						tokens.Add(new Tuple<string, string, int>("invalid token", word, line_no));

					}
				}
				else if (ch == '\'')
				{

					if (check_char(word))
					{

						Class_pt = "char_const";
						string temp = "";
						for (int i = 1; i < word.Length - 1; i++) { temp = temp + word[i]; }
						word = temp;
						tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));

					}
					else
					{

						tokens.Add(new Tuple<string, string, int>("invalid token", word, line_no));

					}
				}
				else if (ch >= '0' && ch <= '9')
				{

					if (check_int(word))
					{

						Class_pt = "int_const";
						tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));

					}

					else if (check_flt(word))
					{

						Class_pt = "float_const";
						tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));

					}

					else
					{

						tokens.Add(new Tuple<string, string, int>("invalid token", word, line_no));

					}
				}
				else if (ch == '.')
				{


					if (check_flt(word))
					{

						Class_pt = "float_const";
						tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));

					}

					else if (word == ".")
					{

						tokens.Add(new Tuple<string, string, int>(".", " ", line_no));

					}

					else
					{

						tokens.Add(new Tuple<string, string, int>("invalid token", word, line_no));

					}
				}
				else if (isPunc(ch))
				{

					Class_pt = word;
					tokens.Add(new Tuple<string, string, int>(Class_pt, "", line_no));

				}


				else if (isOp(ch))
				{

					Class_pt = opclass(word);
					tokens.Add(new Tuple<string, string, int>(Class_pt, word, line_no));

				}


				else
				{

					tokens.Add(new Tuple<string, string, int>("invalid token", word, line_no));

				}


			}
			string path = @"C:\Users\HP\Desktop\SyntaxAnalyzer\output.txt";

			foreach (var item in tokens)
			{

				Console.WriteLine($"({item.Item1} ,{item.Item2} , {item.Item3} )");

				using (StreamWriter sw = File.AppendText(path))
				{
					sw.WriteLine($"({item.Item1} ,{item.Item2} , {item.Item3} )");
				}
			}


		}





		public static bool check_id(string word)
		{
			// 
			if (re_id.IsMatch(word))
			{
				return true;
			}
			else
			{
				return false;
			}

		}
		static string value;
		public static string check_kw(string word)
		{
			keyword_list.TryGetValue(word, out value);
			return value;
		}

		public static bool check_int(string word)
		{
			if (re_int.IsMatch(word))
			{
				return true;
			}
			else
			{
				return false;
			}

		}

		public static bool check_flt(string word)
		{
			if (re_flt.IsMatch(word))
			{
				return true;
			}
			else
			{
				return false;
			}

		}

		public static bool check_char(string word)
		{
			if (re_char.IsMatch(word))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		public static bool check_str(string word)
		{
			if (re_str.IsMatch(word))
			{
				return true;
			}
			else
			{
				return false;
			}


		}

		public static string opclass(string x)
		{

			if (PM.Contains(x)) { return "pm"; }
			else if (Inc_Dec.Contains(x)) { return "inc_dec"; }
			else if (MD.Contains(x)) { return "md"; }
			else if (RO.Contains(x)) { return "ro"; }
			else if (comp_assign.Contains(x)) { return "comp_assign"; }
			else { return "assign"; }

		}


	}


	public class SyntaxAnalyzer
	{

		static int index = 0;
		public List<Tuple<string, string, int>> ts = new List<Tuple<string, string, int>>();
		public SyntaxAnalyzer(List<Tuple<string, string, int>> ts)
		{
			//          

			this.ts = ts;
			
			if (S())
			
			{

				if (ts[index].Item1.Equals("$"))
				{
					Console.WriteLine("no syntax error");
				}
				else
				{
					Console.WriteLine("syntax error at line no " + ts[index].Item3);
					
				}

			}
			else
			{
				Console.WriteLine("syntax error at line no " + ts[index].Item3);
				Console.WriteLine("some where  " + ts[index].Item1 +" & " +ts[index].Item2);
			}


		}



		public bool S()
		{
			if (ts[index].Item2.Equals("public") || ts[index].Item1.Equals("class") )
			{
					if (ts[index].Item2.Equals("public"))
					{
						index++;
					if (ts[index].Item1.Equals("class"))
					{
						index++;
						if (ts[index].Item1.Equals("ID"))
						{
							index++;
							if (inh())
							{
								if (n())
								{
									if (ts[index].Item1.Equals("{"))
								{
									index++;
									if (n())
									{
										if (s1())
										{
											return true;
										}

									}

								}
							}
							}
						 }
					   }
					}
				
				else
				{
					if (ts[index].Item1.Equals("class"))
					{
						index++;
						if (ts[index].Item1.Equals("ID"))
						{
							index++;
							if (inh())
							{
								if (ts[index].Item1.Equals("{"))
								{

									if (n())
									{
										if (s1())
										{
											return true;
										}

									}

								}
							}
						}
					}
				}

			}

			return false;
		}

		public bool defs()
		{
			
			if (ts[index].Item1 == "abstract" || ts[index].Item1 == "sealed" || ts[index].Item1 == "static"
				|| ts[index].Item1 == "class")
			{
				
				if (class_def())
				{
				
					if (n1())
					{
						if (defs())
						{
							return true;
						}
					}
				}
			}

			else if (ts[index].Item1 == "struct")
			{
				if (struct_def())
				{
					if (n1())
					{
						if (defs())
						{
							//index++;
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline") || ts[index].Item2.Equals("public") || ts[index].Item1.Equals("$"))
			{
				

				return true;
			}

		
			return false;


		}
		public bool n()
		{
			
			if (ts[index].Item1.Equals("newline"))
			{
			index++;
				if (n1())
				{
					return true;

				}

			}
			return false;
		}

		public bool n1()
		{
			if (n())
			{
				
				//index++;
				return true;

			}
			else
			{
				if (ts[index].Item1.Equals("newline") || ts[index].Item1.Equals("static") || ts[index].Item1.Equals("class") ||
						ts[index].Item1.Equals("void") || ts[index].Item1.Equals("abstract") || ts[index].Item1.Equals("access-modifier")
						|| ts[index].Item1.Equals("sealed") || ts[index].Item1.Equals("dt") || ts[index].Item1.Equals("ID") ||
						ts[index].Item1.Equals("for") || ts[index].Item1.Equals("do") || ts[index].Item1.Equals("if") ||
						ts[index].Item1.Equals("while") || ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("break") ||
						ts[index].Item1.Equals("continue") || ts[index].Item1.Equals("return") || ts[index].Item1.Equals("struct") ||
						ts[index].Item1.Equals("{") || ts[index].Item1.Equals("}") || ts[index].Item1.Equals("else")
						|| ts[index].Item1.Equals("$"))
				{
					return true;
				}

			}
			return false;
		}



		public bool struct_def()
		{

			if ( ts[index].Item1.Equals("struct"))
			{
				
					if (ts[index].Item1.Equals("struct"))
					{
						index++;
						if (ts[index].Item1.Equals("ID"))
						{
							index++;
							if (n())
							{
								if (ts[index].Item1.Equals("{"))
								{
									index++;
									if (n())
									{
										if (sbody())
										{
											if (ts[index].Item1.Equals("}"))
											{
												index++;
												return true;
											}
										}
									}
								}
							}
						}
					}
				
			}

			return false;
		}

		public bool class_def()
		{
			
			if ( ts[index].Item1.Equals("abstract") || ts[index].Item1.Equals("sealed") ||
				ts[index].Item1.Equals("static") || ts[index].Item1.Equals("class"))
			{
				//index++;
				
					if (ab_seal())
					{
						if (sstatic())
						{
							if (ts[index].Item1.Equals("class"))

							{
								index++;
								

								if (ts[index].Item1.Equals("ID"))
								{
									index++;
									
									if (inh())
									{

										
										if (n())
										{
											
											if (ts[index].Item1.Equals("{"))
											{
												
												index++;
												if (n())
												{
													

													if (c_body())
													{
														

														if (ts[index].Item1.Equals("}"))
														{
															
															index++;
															return true;
														}

													}
												}
											}
										}
									}
								}
							}
						}
					}

				

			}

			return false;

		}
		/*public bool fun_def()
		{
			if (sstatic())
			{
				if (type())
				{
					if (ts[index].Item1.Equals("func"))
					{
						index++;
						
							if (ts[index].Item1.Equals("ID"))
							{
								index++;
								if (ts[index].Item1.Equals("("))
								{
								    index++;
									if (p())
									{
										if (ts[index].Item1.Equals(")"))
										{
										index++;
											if (n())
											{
												if (ts[index].Item1.Equals("{"))
												{
												index++;
													if (n())
													{
														if (MST())
														{
															if (ts[index].Item1.Equals("}"))
															{
															index++;
																return true;
															}

														}
													}
												}
											}
										}
									}
								}
							}
						
					}
				}
			}
			return false;
		} */

		public bool ac()
		{
			if (ts[index].Item1.Equals("public"))
			{
				index++;
				return true;
			}

			else if (ts[index].Item1.Equals("private"))
			{
				index++;
				return true;
			}

			else
			{
				if (ts[index].Item1.Equals("struct") || ts[index].Item1.Equals("static") || ts[index].Item1.Equals("void") || ts[index].Item1.Equals("dt") || ts[index].Item1.Equals("struct") || ts[index].Item1.Equals("ID"))
				{
					//index++;
					return true;
				}
			}
			return false;
		}

		public bool ab_seal()
		{
			if (ts[index].Item1.Equals("sealed"))
			{
				index++;
				return true;
			}
			else if(ts[index].Item1.Equals("abstract"))
            {
				index ++;
				return true;
            }
			else
			{
				if (ts[index].Item1.Equals("static") || ts[index].Item1.Equals("class") ||
					ts[index].Item1.Equals("void") || ts[index].Item1.Equals("dt") ||
					ts[index].Item1.Equals("ID"))
				{

					//index++;
					return true;
				}
			}
			return false;
		}

		public bool acc_mod()
		{
			if (ts[index].Item1.Equals("access-modifier"))
			{
				Console.WriteLine(" acc_mod ka first if");

				index++;
				return true;
			}
			else
			{
				if (ts[index].Item1.Equals("abstract") || ts[index].Item1.Equals("sealed") || ts[index].Item1.Equals("static") || ts[index].Item1.Equals("class") || ts[index].Item1.Equals("void") || ts[index].Item1.Equals("dt"))
				{
					//index++;
					return true;
				}
			}
			return false;
			
		}

		public bool sstatic()
		{
			if (ts[index].Item1.Equals("static"))
			{
				index++;
				return true;
			}
			else
			{
				if (ts[index].Item1.Equals("void") || ts[index].Item1.Equals("sealed") || ts[index].Item1.Equals("class") || ts[index].Item1.Equals("ID") || ts[index].Item1.Equals("dt"))
				{
					//	index++;
					return true;
				}
			}

			return false;
			//return true;
		}

		public bool inh()
		{
			if (ts[index].Item1.Equals(":"))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					return true;
				}
			}
			else
			{
				if (ts[index].Item1.Equals("newline"))
				{
					return true;
				}

			}
			return false;

		}

		public bool do_while()
		{
			if (ts[index].Item1.Equals("do"))
			{
				index++;
				if (n())
				{
                    if (ts[index].Item1.Equals("{"))
					{
						index++;
						if (n())
						{
							if (MST())
							{
								if (ts[index].Item1.Equals("}"))
								{
									index++;
									if (n())
									{ 
										if (ts[index].Item1.Equals("while"))
										{
											index++;
											if (OE())
											{
												if (ts[index].Item1.Equals(":"))
												{
													index++;
													if (n())
													{
														return true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return false;
		}


		public bool while_st()
		{
			if (ts[index].Item1.Equals("while"))
			{
				index++;
				if (OE())
				{
					if (ts[index].Item1.Equals(":"))
					{
						index++;
						if (n())
						{
							if (body())
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}
		public bool if_else()
		{
			if (ts[index].Item1.Equals("if"))
			{
				index++;
				if (OE())
				{
					if (ts[index].Item1.Equals(":"))
					{
						index++;
						if (n())
						{
							if (body())
							{
								if (op_else())
								{
									return true;
								}
							}
						}
					}
				}
			}
			return false;
		}
		public bool op_else()
		{
			if (ts[index].Item1.Equals("else"))
			{
				index++;
				if (n())
				{
					if (body())
					{
						return true;
					}
				}
				else
				{
					if (ts[index].Item1.Equals("newline"))
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool MST()
		{
			if (ts[index].Item1.Equals("if") ||
				ts[index].Item1.Equals("for") ||
				ts[index].Item1.Equals("while") ||
				ts[index].Item1.Equals("do") ||
				ts[index].Item1.Equals("break") ||
				ts[index].Item1.Equals("continue") ||
				ts[index].Item1.Equals("return") ||
				ts[index].Item1.Equals("void") ||
				ts[index].Item1.Equals("dt") ||
				ts[index].Item1.Equals("inc_dec") ||
				ts[index].Item1.Equals("ID"))

			{
				if(SST())
                {
					if(n())
                    {
						if(MST())
                        {
							return true;
						}
                    }
                }
			}
			else
			{
				if (ts[index].Item1.Equals("}"))
				{
					return true;
				}
			}
			return false;
		}
		public bool body()
		{
			if (ts[index].Item1.Equals("if") ||
					ts[index].Item1.Equals("for") ||
					ts[index].Item1.Equals("while") ||
					ts[index].Item1.Equals("do") ||
					ts[index].Item1.Equals("break") ||
					ts[index].Item1.Equals("continue") ||
					ts[index].Item1.Equals("return") ||
					ts[index].Item1.Equals("void") ||
					ts[index].Item1.Equals("dt") ||
					ts[index].Item1.Equals("inc_dec") ||
					ts[index].Item1.Equals("{"))
			{

				if (SST())
				{
					if (n())
					{
						return true;
					}
				}
				else if (ts[index].Item1.Equals("{"))
				{
					index++;
					if (n1())    //changes
					{
						if (MST())
						{
							if (ts[index].Item1.Equals("}"))
							{
								index++;
								//if (n())
								//{
									return true;
								//}
							}
						}
					}
				}
			}
			return false;
		}
		public bool for_st()
		{
			if (ts[index].Item1.Equals("for"))
			{
				index++;
				//if (ts[index].Item1.Equals("("))
				//{
				//	index++;
					if (e1())
				{
					if (ts[index].Item1.Equals(":"))
					{
						index++;
						
							if (e2())
						{
							if (ts[index].Item1.Equals(":"))
							{
								index++;
								if (e3())
								{
									if (n())
									{
										if (body())
										{
											return true;
										}
									}
								}
							}
						}
					}

				}
		//	}
			}
			return false;
		}
		public bool e1()
		{

			//ts[index].Item1.Equals("ID") ||
			if ( ts[index].Item1.Equals("dt"))
			{
				//index++;
				if (dec())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				//index++;
				if (Assign_st())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals(":"))
			{
				//index++;
				return true;
			}
			return false;

		}
		public bool e2()
		{
			if (ts[index].Item1.Equals("ID") || ts[index].Item1.Equals("dt") || 
				ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("(") ||
				ts[index].Item1.Equals("!"))

			{
				//index++;
				if (OE())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals(":"))
			{
				//index++;
				return true;
			}
			return false;
		}
		public bool e3()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				//index++;
				if (e31())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("inc_dec"))
			{
				//index++;
				if (inc_dec_st())
				{
					if (x())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				//index++;
				return true;
			}
			return false;

		}

		public bool e31()
		{
			if (ts[index].Item1.Equals("="))
			{
				index++;
				return true;
			}

			else if (ts[index].Item1.Equals("inc_dec"))
			{
				index++;
				if (inc_dec_st())
				{
					return true;
				}
			}

			return false;
		}
		public bool dec()
		{
			if (ts[index].Item1.Equals("dt"))
			{
				//index++;
				if (DT())
				{
					if (ts[index].Item1.Equals("ID"))
					{
						index++;
						if (init())
						{
							if (list())
							{
								return true;
							}
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (ID())
				{
					if (init())
					{
						if (list())
						{
							return true;
						}
					}

				}
			}
			return false;
		}
		public bool DT()

		{
			if (ts[index].Item2.Equals("str"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item2.Equals("int"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item2.Equals("char"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item2.Equals("float"))
			{
				index++;
				return true;
			}
			return false;
		}

		public bool ID()
		{
			if (ts[index].Item1.Equals(","))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (ID())
					{
						return true;
					}
				}
			}
			else
			{
				if (ts[index].Item1.Equals("(") ||
					 (ts[index].Item1.Equals("{")))
				{
					return true;
				}
			}
			return false;
		}
		public bool init()
		{
			if (ts[index].Item1.Equals("newline") ||
			  ts[index].Item1.Equals(","))
			{
				 index++;
				return true;
			}
			else if (ts[index].Item2.Equals("="))
			{
				index++;
				if (OE())
				{
					return true;
				}
			}
			return false;
		}
		public bool list()
		{
			if (ts[index].Item1.Equals(":"))
			{
				//index++;
				return true;
			}
			
			else if (ts[index].Item1.Equals(","))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (init())
					{
						if (list())
						{
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				//index++;
				return true;
			}
			return false;
		}
		public bool return_st()
		{
			if (ts[index].Item1.Equals("return"))
			{
				index++;
				if (r1())
				{
					return true;
				}
			}
			return false;
		}
		public bool r1()
		{
			if (ts[index].Item1.Equals("ID") || ts[index].Item1.Equals("dt") || ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!"))
			{
				if (OE())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool break_st()
		{
			if (ts[index].Item1.Equals("break"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool continue_st()
		{
			if (ts[index].Item1.Equals("continue"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool Assign_st()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (x())
				{
					if (ts[index].Item1.Equals("="))
					{
						index++;
						if (OE())
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		/*public bool assign_op()
		{
			if (ts[index].Item1.Equals("="))
			{
				index++;
				return true;
			}
			return false;
		}*/

		public bool inc_dec_st()
		{
			if (ts[index].Item1.Equals("ID") || ts[index].Item1.Equals("inc_dec"))
			{
				if (x())
				{
					if (ts[index].Item1.Equals("inc_dec"))
					{
						index++;
						return true;
					}
				}
				else if (ts[index].Item1.Equals("inc_dec"))
				{
					index++;
					if (x())
					{
						return true;
					}

				}
			}
			return false;
		}
		public bool fun_call()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (y())
				{
					return true;
				}
			}
			return false;
		}
		public bool cons_body()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (Assign_st())
				{
					if (n())
					{
						if (cons_body())
						{
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline") || ts[index].Item1.Equals("}"))
			{
				return true;
			}
			return false;
		}
		public bool c_body()
		{
			if (ts[index].Item1.Equals("access-modifier") || ts[index].Item1.Equals("static") || 
				ts[index].Item1.Equals("abstract") || ts[index].Item1.Equals("sealed") ||
				ts[index].Item1.Equals("dt") || ts[index].Item1.Equals("ID") || ts[index].Item1.Equals("void"))
			{
				//	index++;
				if (acc_mod())
				{
					if (sstatic())
					{
						if (c_body1())
						{
							if (n())
							{
								if (c_body())
								{
									return true;
								}
							}
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline") || ts[index].Item1.Equals("public") || 
				ts[index].Item1.Equals("}"))
			{
				return true;
			}
			return false;
		}
		public bool c_body1()
		{
			if (ts[index].Item1.Equals("abstract") || ts[index].Item1.Equals("sealed") || ts[index].Item1.Equals("dt") || ts[index].Item1.Equals("ID") || ts[index].Item1.Equals("void"))
			{
				//index++;
				if (ab_seal())
				{
					if (c())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (c11())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("dt"))
			{
				index++;
				if (DT())
				{
					if (c2())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool c()
		{
			if (ts[index].Item1.Equals("dt"))// || ts[index].Item1.Equals("id") || ts[index].Item1.Equals("void"))
			{
				index++;
				if (DT())
				{
					if (c1())
					{
						return true;
					}
				}
			}

			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (c3())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("void"))
			{
				index++;
				if (ts[index].Item1.Equals("func"))
				{
					index++;
					if (ts[index].Item1.Equals("ID"))
					{
						index++;
						if (ts[index].Item1.Equals("("))
						{
							index++;
							if (p())
							{
								if (ts[index].Item1.Equals(")"))
								{
									index++;
									if (n())
									{
										if (ts[index].Item1.Equals("{"))
										{
											index++;
											if (n())
											{
												if (MST())
												{
													if (ts[index].Item1.Equals("}"))
													{
														index++;
														return true;
													}

												}
											}
										}
									}
								}
							}
						}
					}
					
					else if (ts[index].Item1.Equals("main"))
						{
							index++;
						if (ts[index].Item1.Equals("("))
						{
							index++;
							if (ts[index].Item1.Equals(")"))
							{
								index++;
								if (n())
								{
									if (ts[index].Item1.Equals("{"))
									{
										index++;
										if (n())
										{
											if (MST())
											{
												if (ts[index].Item1.Equals("}"))
												{
													index++;
													return true;
												}
											}
										}
									}

								}
							}
						}
						
					}
				}
			}
			return false;
		}
		public bool c1()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (init())
				{
					if (list())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("void") || ts[index].Item1.Equals("dt"))
			{
				if (type1())
				{
					if (ts[index].Item1.Equals("func"))
					{
						index++;
						{
							if (ts[index].Item1.Equals("ID"))
							{
								index++;
								if (ts[index].Item1.Equals("("))
								{
									index++;
									if (p())
									{
										if (ts[index].Item1.Equals(")"))
										{
											index++;
											if (n())
											{
												if (ts[index].Item1.Equals("{"))
												{
													index++;
													if (n())
													{
														if (MST())
														{
															if (ts[index].Item1.Equals("}"))
															{
																index++;
																return true;
															}

														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return false;
		}
		public bool c11()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (arr())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("("))
			{
				index++;
				if (p())
				{
					if (ts[index].Item1.Equals(")"))
					{
						index++;
						if (ts[index].Item1.Equals("{"))
						{
							index++;
							if (n())
							{
								if (cons_body())
								{
									if (ts[index].Item1.Equals("}"))
									{
										index++;
										return true;
									}
								}
							}
						}

					}
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (ts[index].Item1.Equals("="))
				{
					index++;
					if (ts[index].Item1.Equals("new"))
					{
						index++;
						if (ts[index].Item1.Equals("ID"))
						{
							index++;
							if (y())
							{
								return true;
							}
						}
					}

				}
			}
			return false;
		}
		public bool c2()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (arr())
				{
					return true;
				}
			}
			return false;
		}
		public bool c3()
		{
			if (ts[index].Item1.Equals("[") || ts[index].Item1.Equals("func"))
			{
				//index++;
				if (type1())
				{
					if (ts[index].Item1.Equals("func"))
					{
						index++;
						if (ts[index].Item1.Equals("ID"))
						{
							index++;
							if (ts[index].Item1.Equals("("))
							{
								index++; 
								if (p())
								{
									if (ts[index].Item1.Equals(")"))
									{
										index++;
										if (n())
										{
											if (ts[index].Item1.Equals("{"))
											{
												index++;
												if (n())
												{
													if (MST())
													{
														if (ts[index].Item1.Equals("}"))
														{
															index++;
															return true;
														}
													}
												}
											}
										}
									}
								}
							}
						}

					

					}
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (init())
				{
					if (list())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool p()
		{
			if (ts[index].Item1.Equals("dt"))
			{
				index++;
				if (p1())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (p1())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals(")"))
			{
				//index++;
				return true;
			}
			return false;
		}
		public bool p1()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (p111())
				{
					if (p3())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool p2()
		{
			if (ts[index].Item1.Equals("]"))
			{
				index++;
				if (p3())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals(","))
			{
				index++;
				if (ts[index].Item1.Equals("]"))
				{
					index++;
					if (p3())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool p3()
		{
			if (ts[index].Item1.Equals(","))
			{
				index++;
				if (p11())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals(")"))
			{
				//index++;
				return true;
			}
			return false;
		}
		public bool p11()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item1.Equals("."))
			{
				//index++;
				return true;
			}
			return false;
		}
		public bool p111()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (p2())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals(")") || ts[index].Item1.Equals(","))
			{
				return true;
			}
			return false;
		}
		public bool type()
		{
			if (ts[index].Item1.Equals("dt"))
			{
				index++;
				if (DT())
				{
					if (type1())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("void"))
			{
				//index++;
				return true;
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (type1())
				{
					return true;
				}
			}
			return false;
		}
		public bool type1()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (t2())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("func"))
			{
				//index++;
				return true;
			}
			return false;
		}
		public bool t2()
		{
			if (ts[index].Item1.Equals("]"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item1.Equals(","))
			{
				index++;
				if (ts[index].Item1.Equals("]"))
				{
					index++;
					return true;
				}
			}
			return false;
		}

		public bool arr_def()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (arr())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("dt"))
			{
				index++;
				if (DT())
				{
					if (arr())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool arr()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (arr1())
				{
					return true;
				}
			}
			return false;
		}
		public bool arr1()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (arr11())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals(","))
			{
				index++;
				if (ts[index].Item1.Equals("["))
				{
					index++;
					if (ts[index].Item1.Equals("ID"))
					{
						index++;
						if (arr11())
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		public bool arr11()
		{
			if (ts[index].Item1.Equals("="))
			{
				index++;
				if (arr111())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool arr111()
		{
			if (ts[index].Item1.Equals("new"))
			{
				index++;
				if (arr2())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("{"))
			{
				index++;
				if (values())
				{
					if (ts[index].Item1.Equals("}"))
					{
						index++;
						return true;
					}
				}
			}
			return false;
		}
		public bool arr2()
		{
			if (ts[index].Item1.Equals("dt"))
			{
				index++;
				if (DT())
				{
					if (ts[index].Item1.Equals("["))
					{
						index++;
						if (OE())
						{
							if (arr3())
							{
								return true;
							}
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (ts[index].Item1.Equals("["))
				{
					index++;
					if (OE())
					{
						if (arr3())
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		public bool arr3()
		{
			if (ts[index].Item1.Equals("]"))
			{
				index++;
				if (ts[index].Item1.Equals("{"))
				{
					index++;
					if (values())
					{
						if (ts[index].Item1.Equals("}"))
						{
							index++;
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals(","))
			{
				index++;
				if (OE())
				{
					if (ts[index].Item1.Equals("]"))
					{
						index++;
						if (ts[index].Item1.Equals("{"))
						{
							index++;
							if (values())
							{
								if (ts[index].Item1.Equals("}"))
								{
									index++;
									return true;
								}
							}
						}
					}
				}
			}
			return false;
		}
		public bool values()
		{
			if (ts[index].Item1.Equals("dt") || ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!") || ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("ID"))
			{
				if (OE())
				{
					if (v())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool values1()
		{
			if (ts[index].Item1.Equals("{"))
			{
				index++;
				if (values())
				{
					if (ts[index].Item1.Equals("}"))
					{
						index++;
						if (v1())
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		public bool v()
		{
			if (ts[index].Item1.Equals(","))
			{
				index++;
				if (OE())
				{
					if (v1())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool v1()
		{
			if (ts[index].Item1.Equals(","))
			{
				index++;
				if (ts[index].Item1.Equals("{"))
				{
					index++;
					if (values1())
					{
						if (ts[index].Item1.Equals("}"))
						{
							index++;
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool sbody()
		{
			if (ts[index].Item1.Equals("private") || ts[index].Item1.Equals("public") ||
				ts[index].Item1.Equals("static") || ts[index].Item1.Equals("void") ||
				ts[index].Item1.Equals("ID") || ts[index].Item1.Equals("dt"))
			{
				if (ac())
				{
					if (sstatic())
					{
						if (sbody1())
						{
							if (n())
							{
								if (sbody())
								{
									return true;
								}
							}
						}
					}
				} 
			}
			else if (ts[index].Item1.Equals("}"))
			{
				return true;
			}
			else
			{
				if (struct_def())
				{
					return true;
				}
			}
			
			return false;

		}
		public bool sbody1()
		{
			if (ts[index].Item1.Equals("void"))
			{
				index++;
				if (ts[index].Item1.Equals("func"))
				{
					index++;
					if (ID())
					{
						if (ts[index].Item1.Equals("("))
						{
							index++;
							if (p())
							{
								if (ts[index].Item1.Equals(")"))
								{
									index++;
									if (ts[index].Item1.Equals("{"))
									{
										index++;
										if (MST())
										{
											if (ts[index].Item1.Equals("}"))
											{
												index++;
												return true;
											}
										}
									}
								}
							}

						}
					}
				}
			}
			else if (ts[index].Item1.Equals("dt"))
			{
				index++;
				if (sb())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (sb1())
				{
					return true;
				}
			}
			return false;
		}
		public bool sb()
		{
			if (ts[index].Item1.Equals("func"))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (ts[index].Item1.Equals("("))
					{
						index++;
						if (p())
						{
							if (ts[index].Item1.Equals(")"))
							{
								index++;
								if (ts[index].Item1.Equals("{"))
								{
									index++;
									if (MST())
									{
										if (ts[index].Item1.Equals("}"))
										{
											index++;
											return true;
										}
									}
								}
							}
						}

					}
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (arr())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (init())
				{
					if (list())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool sb1()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (arr())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("("))
			{
				index++;
				if (p())
				{
					if (ts[index].Item1.Equals(")"))
					{
						index++;
						if (ts[index].Item1.Equals("{"))
						{
							index++;
							if (cons_body())
							{
								if (ts[index].Item1.Equals("}"))
								{
									index++;
									return true;
								}
							}
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("func"))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (ts[index].Item1.Equals("("))
					{
						index++;
						if (p())
						{
							if (ts[index].Item1.Equals(")"))
							{
								index++;
								if (ts[index].Item1.Equals("{"))
								{
									index++;
									if (MST())
									{
										if (ts[index].Item1.Equals("}"))
										{
											index++;
											return true;
										}
									}
								}
							}
						}
					}
				}
			}
			return false;
		}
		public bool constant()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") || ts[index].Item1.Equals("char_const") || ts[index].Item1.Equals("float_const"))

			{
				index++;
				return true;
			}
			return false;
		}
		public bool PL()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") || ts[index].Item1.Equals("char_const") || ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!") || ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("ID") || ts[index].Item1.Equals(")"))
			{
				//index++;
				if (OE())
				{
					if (PL1())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool PL1()
		{
			if (ts[index].Item1.Equals(","))
			{
				index++;
				if (OE())
				{
					if (PL1())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals(")"))
			{
				return true;
			}
			return false;
		}
		public bool OE()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") || 
				ts[index].Item1.Equals("char_const") || ts[index].Item1.Equals("float_const") || 
				ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!") || ts[index].Item1.Equals("inc_dec") 
				|| ts[index].Item1.Equals("ID"))
			{
				if (AE())
				{
					if (OE1())
					{
						return true;
					}
				}
			}
			return false;

		}
		public bool OE1()
		{
			if (ts[index].Item1.Equals("or"))
			{
				index++;

				if (AE())
				{
					if (OE1())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals(")") || ts[index].Item1.Equals("]") || ts[index].Item1.Equals(":")
				|| ts[index].Item1.Equals(",") || ts[index].Item1.Equals("newline"))
			{
				//index++;
				return true;

			}
			return false;
		}
		public bool AE()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") || 
				ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("char_const") || 
				ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!") || ts[index].Item1.Equals("inc_dec") 
				|| ts[index].Item1.Equals("ID"))
			{
				//index++;
				if (RE())
				{
					if (AE1())

					{
						return true;
					}
				}
			}
			return false;
		}
		public bool AE1()
		{
			if (ts[index].Item1.Equals("and"))
			{
				index++;
				if (RE())
				{
					if (AE1())
					{
						return true;

					}
				}
			}
			else if (ts[index].Item1.Equals("or") || ts[index].Item1.Equals(")") || ts[index].Item1.Equals("]") 
				|| ts[index].Item1.Equals(":") || ts[index].Item1.Equals(",") || ts[index].Item1.Equals("newline"))
			{
				//index++;
				return true;
			}
			return false;

		}
		public bool RE()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") || 
				ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("char_const") ||
				ts[index].Item1.Equals("char_const") || ts[index].Item1.Equals("(") || 
				ts[index].Item1.Equals("!") || ts[index].Item1.Equals("inc_dec") || 
				ts[index].Item1.Equals("ID"))
			{
				//index++;
				if (E())
				{
					if (RE1())
					{
						return true;

					}
				}
			}
			return false;
		}
		public bool RE1()
		{
			if (ts[index].Item1.Equals("ro"))
			{
				index++;
				if (E())
				{
					if (RE1())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("and") || ts[index].Item1.Equals("or") || ts[index].Item1.Equals(")")
				|| ts[index].Item1.Equals("]") || ts[index].Item1.Equals(":") || ts[index].Item1.Equals("newline")
				|| ts[index].Item1.Equals(","))
			{
				//index++;
				return true;

			}
			return false;
		}
		public bool E()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") ||
				ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("char_const") 
				|| ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!") || 
				ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("char_const") || 
				ts[index].Item1.Equals("!") || ts[index].Item1.Equals("ID"))
			{
				// index++;
				if (T())
				{
					if (E1())
				{
					return true;
				}
			}
			}
			return false;
		}
		public bool E1()
		{
			if (ts[index].Item1.Equals("pm"))
			{
				index++;
				if (T())
				{
					if (E1())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("and") || ts[index].Item1.Equals("or") ||
				ts[index].Item1.Equals("]") || ts[index].Item1.Equals(")") || ts[index].Item1.Equals(",")
				|| ts[index].Item1.Equals("ro") || ts[index].Item1.Equals(":") || ts[index].Item1.Equals("newline"))
			{
				//index++;
				return true;
			}
			return false;
		}
		public bool T()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") ||
				ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("char_const") ||
				ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!") || 
				ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("ID"))
			{
				// index++;
				if (F())
				{
					if (T1())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool T1()
		{
			if (ts[index].Item1.Equals("mdm"))
			{
				index++;
				if (F())
				{
					if (T1())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("pm") || ts[index].Item1.Equals("and") || ts[index].Item1.Equals("or")
				|| ts[index].Item1.Equals("]") || ts[index].Item1.Equals(")") || ts[index].Item1.Equals(",") ||
				ts[index].Item1.Equals("ro") || ts[index].Item1.Equals(":") || ts[index].Item1.Equals("newline")||
				ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") ||
				ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("char_const"))
			{
				return true;
			}
			return false;
		}
		public bool F()
		{
			if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") ||
				ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("char_const"))
			{
				if (constant())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("("))
			{
				index++;
				if (E())
				{
					if (ts[index].Item1.Equals(")"))
					{
						index++;
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("!"))
			{
				index++;
				if (F())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("inc_dec"))
			{
				index++;
				if (x())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (F1())
				{
					return true;
				}
			}
			return false;
		}
		public bool F1()
		{
			if (ts[index].Item1.Equals(".") || ts[index].Item1.Equals("inc_dec") ||
				ts[index].Item1.Equals("[") || ts[index].Item1.Equals("("))
			{
				if (z())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			else if (ts[index].Item1.Equals("mdm") || ts[index].Item1.Equals("pm") || 
				ts[index].Item1.Equals("and") || ts[index].Item1.Equals("or") || 
				ts[index].Item1.Equals("]") || ts[index].Item1.Equals(")") || ts[index].Item1.Equals(",") 
				|| ts[index].Item1.Equals("ro") || ts[index].Item1.Equals(":"))
			{
				return true;
			}
			
			return false;
		}
		/*if(F11())
		{
			return true;
		}
	}
}
else if(ts[index].Item1.Equals("MDM")|| ts[index].Item1.Equals("PM") || ts[index].Item1.Equals("AND") || ts[index].Item1.Equals("OR") || ts[index].Item1.Equals("]") || ts[index].Item1.Equals(")") || ts[index].Item1.Equals(",") || ts[index].Item1.Equals("ROP") || ts[index].Item1.Equals(":") || ts[index].Item1.Equals("\n"))
{
	if()
}*/


		public bool z()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (z())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (OE())
				{
					if (w1())
					{
						if (z1())
						{
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("inc_dec"))
			{
				return true;
			}
			else if (ts[index].Item1.Equals("("))
			{
				index++;
				if (p())
				{
					if (ts[index].Item1.Equals(")"))

					{
						index++;
						if (z2())
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		public bool z1()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					return true;
				}
			}
			else if (ts[index].Item1.Equals("inc_dec"))
			{
				return true;
			}
			return false;
		}
		public bool z2()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (z())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (OE())
				{
					if (w1())
					{
						if (z1())
						{
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool y()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (y())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("("))
			{
				index++;
				if (PL())
				{
					if (ts[index].Item1.Equals(")"))
					{
						index++;
						if (y1())
						{
							return true;
						}
					}

				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (a())
				{
					if (ts[index].Item1.Equals("."))
					{
						index++;
						if (ts[index].Item1.Equals("ID"))
						{
							index++;
							if (y())
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}
		public bool y1()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (y())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (a())
				{
					if (ts[index].Item1.Equals("ID"))
                    {
						index++;
						if (y())
						{
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool a()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (OE())
				{
					if (w1())
					{
						return true;
					}
				}

			}
			return false;
		}
		public bool x()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (x1())
				{
					return true;
				}
			}
			return false;
		}
		public bool x1()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (x2())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (x3())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("MDM") || ts[index].Item1.Equals("=") || ts[index].Item1.Equals("PM") || ts[index].Item1.Equals("AND") || ts[index].Item1.Equals("OR") || ts[index].Item1.Equals("]") || ts[index].Item1.Equals(")") || ts[index].Item1.Equals(",") || ts[index].Item1.Equals("ROP") || ts[index].Item1.Equals(":") || ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool x2()
		{
			if (ts[index].Item1.Equals(".") || ts[index].Item1.Equals("[") || ts[index].Item1.Equals("newline"))
			{
				if (x1())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("("))
			{
				index++;
				if (x4())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool x3()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (OE())
				{
					if (w1())
					{
						if (x1())
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		public bool x4()
		{
			if (ts[index].Item1.Equals("("))
			{
				index++;
				if (PL())
				{
					if (ts[index].Item1.Equals(")"))
					{
						index++;
						if (x41())
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		public bool x41()
		{
			if (ts[index].Item1.Equals("["))
			{
				index++;
				if (x3())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (x())
				{
					return true;
				}
			}
			return false;
		}
		public bool w()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (w())
					{
						return true;
					}
				}

			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (OE())
				{
					if (w1())
					{
						if (w2())
						{
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("inc_dec"))
			{
				index++;
				return true;
			}
			else if (ts[index].Item1.Equals("="))
			{
				index++;
				if (OE())
				{
					return true;
				}

			}
			else if (ts[index].Item1.Equals("("))
			{
				index++;
				if (PL())
				{
					if (ts[index].Item1.Equals(")"))
					{
						index++;
						if (w3())
						{
							return true;
						}
					}
				}

			}
			return false;
		}
		public bool w1()
		{
			if (ts[index].Item1.Equals("]"))
			{
				return true;
			}
			else if (ts[index].Item1.Equals(","))
			{
				index++;
				if (OE())
				{
					if (ts[index].Item1.Equals("]"))
					{
						index++;
						return true;
					}
				}
			}
			return false;
		}
		public bool w2()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (w())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("inc_dec"))
			{
				return true;
			}
			else if (ts[index].Item1.Equals("="))
			{
				index++;
				if (OE())
				{
					return true;
				}

			}
			return false;
		}
		public bool w3()
		{
			if (ts[index].Item1.Equals("."))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (w())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (OE())
				{
					if (w1())
					{
						if (w2())
						{
							return true;
						}
					}
				}
			}
			else if (ts[index].Item1.Equals("newline"))
			{
				return true;
			}
			return false;
		}
		public bool SST()
		{
			if (ts[index].Item1.Equals("while"))
			{
				//index++;
				if (while_st())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("for"))
			{
				//index++;
				if (for_st())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("if"))
			{
				//index++;
				if (if_else())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("else"))
			{
				//index++;
				if (op_else())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("continue"))
			{
				//index++;
				if (continue_st())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("break"))
			{
				//index++;
				if (break_st())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("return"))
			{
				//index++;
				if (return_st())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("do"))
			{
				//index++;
				if (do_while())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("inc_dec"))
			{
				//index++;
				//if (ts[index].Item1.Equals("ID"))
				//{
					//index++;
					if (x())
					{
						return true;
					}
				//}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (SST1())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("dt"))
			{
				//index++;
				if (DT())
				{
					if (SST2())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("void"))
			{
				index++;
				if (ts[index].Item1.Equals("func"))
				{
					index++;
					if (ts[index].Item1.Equals("ID"))
					{
						index++;
						if (ts[index].Item1.Equals("("))
						{
							index++;
							if (p())
							{
								if (ts[index].Item1.Equals(")"))
								{
									index++;
									if (n())
									{
										if (ts[index].Item1.Equals("{"))
										{
											index++;
											if (n())
											{
												if (MST())
												{
													if (ts[index].Item1.Equals("}"))
													{
														index++;
														return true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return false;
		}
		public bool SST1()
		{
			if (ts[index].Item1.Equals(".") || ts[index].Item1.Equals("[") || 
				ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("=") || 
				ts[index].Item1.Equals("("))
			{
				if (w())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (SST11())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (SST3())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("func"))
			{
				index++;
				if (SST5())
				{
					return true;
				}
			}
			return false;
		}
		public bool SST11()
		{
			if (ts[index].Item1.Equals("]"))
			{
				index++;
				if (SST4())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals(","))
			{
				index++;
				if (ts[index].Item1.Equals("]"))
				{ 
					index++;
					if (SST4())
					{
						return true;
					}
				}
			}
			return false;
		}
		public bool SST2()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (init())
				{
					if (list())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("["))
			{
				index++;
				if (SST11())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("func"))
			{
				//index++;
				if (SST5())
				{
					return true;
				}
			}
			return false;
		}
		public bool SST3()
		{
			if (ts[index].Item1.Equals("="))
			{
				index++;
				if (SST31())
				{
					return true;
				}
			}
			return false;
		}
		public bool SST31()
		{
			if (ts[index].Item1.Equals("new"))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (y())
					{
						return true;
					}
				}
			}
			else if (ts[index].Item1.Equals("int_const") || ts[index].Item1.Equals("str_const") || ts[index].Item1.Equals("char_const") || ts[index].Item1.Equals("float_const") || ts[index].Item1.Equals("(") || ts[index].Item1.Equals("!") || ts[index].Item1.Equals("inc_dec") || ts[index].Item1.Equals("ID"))
			{
				if (OE())
				{
					return true;
				}
			}
			return false;
		}
		public bool SST4()
		{
			if (ts[index].Item1.Equals("ID"))
			{
				index++;
				if (arr11())
				{
					return true;
				}
			}
			else if (ts[index].Item1.Equals("func"))
			{
				index++;
				if (SST5())
				{
					return true;
				}
			}
			return false;
		}
		public bool SST5()
		{
			
			if (ts[index].Item1.Equals("func"))
			{
				index++;
				if (ts[index].Item1.Equals("ID"))
				{
					index++;
					if (ts[index].Item1.Equals("("))
					{
						index++;
						if (p())
						{
							if (ts[index].Item1.Equals(")"))
							{
								index++;
								if (n())
								{
									if (ts[index].Item1.Equals("{"))
									{
										index++;
										if (n())
										{
											if (MST())
											{
												if (ts[index].Item1.Equals("}"))
												{
													index++;
													return true;
												}
											}
										}
									}
								}
							}
						}
					}
				}

			}
			return false;
		}




		public bool s1() {
			if (ts[index].Item2 == "public" || ts[index].Item2 == "private" || ts[index].Item2 == "protected" || 
				ts[index].Item1 == "static" || ts[index].Item1 == "sealed" || ts[index].Item1 == "abstract" ||
				ts[index].Item1 == "void" || ts[index].Item1 == "dt" || ts[index].Item1 == "id")
			{
				if (ts[index].Item2 == "public")
				{
					index++;
					if (s2())
					{
						return true;
					}
				}
				else if (ts[index].Item2 == "private")
				{
					index++;
					if (sstatic())
					{
						if (c_body1())
						{
							if (n())
							{
								if (c_body())
								{
									return true;
								}
							}
						}
					}

				}
				else if (ts[index].Item2 == "protected")
				{
					index++;
					if (sstatic())
					{
						if (c_body1())
						{
							if (n())
							{
								if (c_body())
								{
									return true;
								}
							}
						}
					}
				}
				else if (sstatic())
				{
						if (c_body1())
						{
							if (n())
							{
								if (c_body())
								{
									return true;
								}
							}
						}
					

				}


			}
			return false; }
		public bool s2() {
			if (ts[index].Item1 == "dt" || ts[index].Item1 == "void" || ts[index].Item1 == "ID" ||
				ts[index].Item1 == "abstract" || ts[index].Item1 == "sealed" || ts[index].Item1 == "static") {
				if (ts[index].Item1 == "static")
				{
					index++;
					if (s3())
					{
						return true;
					}
				}
				else
				{
					if (c_body1())
					{
						if (n())
						{
							if (c_body())
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}
		public bool s3() {
			if (ts[index].Item1 == "dt" || ts[index].Item1 == "void" || ts[index].Item1 == "ID" || 
				ts[index].Item1 == "abstract" || ts[index].Item1 == "sealed") {

				if (ts[index].Item1 == "void")
				{
					index++;
					if (ts[index].Item1 == "func") {
						index++;
						if (s4())
						{
							return true;
						} }
				}
				else if (ts[index].Item1 == "dt")
				{
					index++;
					if (c1())
					{
						return true;
					}
				}
				else if (ts[index].Item1 == "ID")
				{
					index++;
					if (c3())
					{
						return true;
					}
				}
				else if (ts[index].Item1 == "abtract")
				{
					index++;
					if (s5())
					{
						return true;
					}
				}
				else if (ts[index].Item1 == "sealed")
				{
					index++;
					if (s5())
					{
						return true;
					}
				}
			}
			return false; 
		}
		public bool s4() {
			if (ts[index].Item1 == "main" || ts[index].Item1 == "ID") {
				if (ts[index].Item1 == "main")
				{
					index++;
					if (ts[index].Item1 == "(")
					{
						index++;
						if (ts[index].Item1 == ")")
						{
							index++;
							if (n())
							{
								if (ts[index].Item1 == "{")
							{
								index++;
								if (n())
								{
									if (MST())
									{
										if (ts[index].Item1 == "}")
										{
											index++;
											if (n())
											{
												if (c_body())
												{ 
													if (ts[index].Item1 == "}")
													{
															index++;
															if (n())
															{
																if (defs())
																{
																	if (n1())
																	{
																		return true;
																	}

																}
															}
													}

												}

											}

										}

									}

								}

							}
						}
						}

					}

				}
				else
				{
				
						if (ts[index].Item1 == "ID")
						{
							index++;
							if (ts[index].Item1 == "(")
							{
								index++;
								if (p())
								{
									if (ts[index].Item1 == ")")
									{
										index++;
										if (ts[index].Item1 == "{")
										{
											index++;
											if (n())
											{
												if (MST())
												{
													if (ts[index].Item1 == "}")
													{
														index++;

													}

												}

											}

										}

									}

								}

							}

						

					}
				}
			}
			return false; }
		public bool s5() {
			if (ts[index].Item1 == "dt" || ts[index].Item1 == "ID" || ts[index].Item1 == "void") {
				if (ts[index].Item1 == "dt")
				{
					index++;
					if (c1())
					{
						return true;
					}
				}
				else if (ts[index].Item1 == "ID")
				{
					index++;
					if (c3())
					{
						return true;
					}
				}
				else if (ts[index].Item1 == "void")
				{
					index++;
					if (ts[index].Item1 == "func")
					{
						index++;
						if (ts[index].Item1 == "ID")
						{
							index++;
							if (ts[index].Item1 == "(")
							{
								index++;
								if (p())
								{
									if (ts[index].Item1 == ")")
									{
										index++;
										if (ts[index].Item1 == "{")
										{
											index++;
											if (n())
											{
												if (MST())
												{
													if (ts[index].Item1 == "}")
													{
														index++;

													}

												}

											}

										}

									}

								}

							}

						}

					}
				}
			}
			return false; }

	}
}







