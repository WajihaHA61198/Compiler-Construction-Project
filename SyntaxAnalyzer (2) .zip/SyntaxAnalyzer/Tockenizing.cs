﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace SyntaxAnalyzer
{
	public class Tokenizing
	{
		static char[] op = { '+', '-', '*', '/', '<', '>', '=', '!', '&', '|' };
		static char[] punc = { '.', ',', ':', '{', '}', '(', ')', ';' };
		public static List<Tuple<int, string>> mylist = new List<Tuple<int, string>>();



		public static void break_words(string inputtext)
		{


			int line_count = 1;
			string temp_word = null;

			for (int i = 0; i < inputtext.Length; i++)
			{
				//	char temp = inputtext[i];

				if (inputtext[i] == '\'')
				{
					if (temp_word != null)
					{
						mylist.Add(new Tuple<int, string>(line_count, temp_word));

						temp_word = null;
					}

					if (inputtext[i + 1] == '\\')
					{
						for (int j = 0; j < 4; j++)
						{
							if (inputtext[i + j] == '\r')
							{

								mylist.Add(new Tuple<int, string>(line_count, temp_word));
								temp_word = null;
								line_count++;
								break;

							}
							else
							{
								temp_word = temp_word + inputtext[i + j];

							}
						}
						//word.Add(temp_word);
						if (temp_word != null)
						{

							mylist.Add(new Tuple<int, string>(line_count, temp_word));
							temp_word = null;
						}
						//i = i + 4;
						i = i + 3;
					}
					else
					{
						for (int j = 0; j < 3; j++)
						{
							if (inputtext[i + j] == '\r')
							{
								temp_word = temp_word + inputtext[i];
								mylist.Add(new Tuple<int, string>(line_count, temp_word));
								temp_word = null;
								line_count++;
								break;

							}
							else
							{
								temp_word = temp_word + inputtext[i + j];

							}

						}
						if (temp_word != null)
						{

							mylist.Add(new Tuple<int, string>(line_count, temp_word));
							temp_word = null;
						}


						// add an item
						i = i + 2;
					}


					temp_word = null;
				}
				else if (inputtext[i] == '\"')
				{

					if (temp_word != null)
					{
						mylist.Add(new Tuple<int, string>(line_count, temp_word));

						temp_word = null;
					}
					//temp_word = temp_word + temp;

					while (i < inputtext.Length)
					{
						if (inputtext[i + 1] == '\r')
						{
							temp_word = temp_word + inputtext[i];
							mylist.Add(new Tuple<int, string>(line_count, temp_word));

							line_count++;
							break;

						}
						else if (inputtext[i + 1] == '\"')
						{
							temp_word = temp_word + inputtext[i];
							temp_word = temp_word + inputtext[i + 1];

							break;

						}
						else
						{
							temp_word = temp_word + inputtext[i];

						}

						i++;
					}
					//	word.Add(temp_word);
					// add an item
					if (inputtext[i + 1] != '\r')
					{
						mylist.Add(new Tuple<int, string>(line_count, temp_word));

					}
					i++;
					temp_word = null;
				}

				else if (inputtext[i] == ' ' || inputtext[i] == '\t' || inputtext[i] == '\n' || inputtext[i] == '\r' || isPunc(inputtext[i]))
				{

					int flag = 0;
					if (inputtext[i] == '\r')
					{
						if (temp_word != null)
						{

							mylist.Add(new Tuple<int, string>(line_count, temp_word));
							temp_word = null;
							//	line_count++;
							//temp = '\0';

						}
						mylist.Add(new Tuple<int, string>(line_count, "nl"));

						line_count++;

					}

					else if (isPunc(inputtext[i]))
					{

						if (inputtext[i] == '.')
						{
							if (temp_word != null)
							{
								for (int j = 0; j < temp_word.Length; j++)
								{
									if ((temp_word[j] >= '0' && temp_word[j] <= '9') && temp_word[j] != '.')
									{
										flag = 1;

									}
									else
									{
										flag = 0;
										break;
									}
								}
								if (flag == 1 && (inputtext[i + 1] >= '0' && inputtext[i + 1] <= '9'))
								{
									temp_word = temp_word + inputtext[i];
									temp_word = temp_word + inputtext[i + 1];
									i++;

								}
								else
								{

									//word.Add(temp_word);
									//word.Add(temp.ToString());
									// add an item
									mylist.Add(new Tuple<int, string>(line_count, temp_word));
									temp_word = null;
									i--;
								}
							}

							else
							{

								if ((inputtext[i + 1] >= '0' && inputtext[i + 1] <= '9'))
								{
									temp_word = temp_word + inputtext[i];
									temp_word = temp_word + inputtext[i + 1];
									i++;
								}
								else
								{
									mylist.Add(new Tuple<int, string>(line_count, inputtext[i].ToString()));
								}

							}



						}
						else
						{
							if (temp_word != null)
							{
								//word.Add(temp_word);
								mylist.Add(new Tuple<int, string>(line_count, temp_word));
							}
							// add an item
							mylist.Add(new Tuple<int, string>(line_count, inputtext[i].ToString()));

							temp_word = null;
						}

					}

					else if (temp_word != null)
					{
						//word.Add(temp_word);
						// add an item
						mylist.Add(new Tuple<int, string>(line_count, temp_word));

						temp_word = null;

					}

				}

				else if (isOp(inputtext[i]))
				{


					if (temp_word != null)
					{
						//word.Add(temp_word);
						// add an item
						mylist.Add(new Tuple<int, string>(line_count, temp_word));
						temp_word = null;

					}


					if ((inputtext[i] == '&' && inputtext[i + 1] == '&') || (inputtext[i] == '|' && inputtext[i + 1] == '|'))
					{    // logical op
						temp_word = inputtext[i] + inputtext[i + 1].ToString();
						//word.Add(temp_word);
						i++;

					}
					else if ((inputtext[i] == '+' && inputtext[i + 1] == '+') || (inputtext[i] == '-' && inputtext[i + 1] == '-'))
					{     // incre decre op
						temp_word = inputtext[i] + inputtext[i + 1].ToString();

						i++;
					}
					else if ((inputtext[i] == '+' || inputtext[i] == '-' || inputtext[i] == '*' || inputtext[i] == '/' || inputtext[i] == '>' || inputtext[i] == '<' || inputtext[i] == '=' || inputtext[i] == '!') && (inputtext[i + 1] == '='))
					{     // comp op
						temp_word = inputtext[i] + inputtext[i + 1].ToString();
						//mylist.Add(new Tuple<int, string>(line_count, temp_word));

						i++;
					}

					else
					{
						// add an item
						mylist.Add(new Tuple<int, string>(line_count, inputtext[i].ToString()));

						temp_word = null;


					}

					//temp_word = null;
				}
				// single line comment
				else if (inputtext[i] == '#' && inputtext[i + 1] == '#')
				{
					i += 2;
					while (inputtext[i] != '\r')
					{

						if (inputtext[i + 1] == '\r') line_count++;
						i++;
					}

				}

				//multi line comment
				else if (inputtext[i] == '~' && inputtext[i + 1] == '~' && inputtext[i + 2] == '~')
				{
					bool check = false;

					i += 2;

					while (i < inputtext.Length)
					{
						if (inputtext[i] == '\r')
						{
							line_count++;
							i++;

						}
						else if (inputtext[i] == '~' && inputtext[i + 1] == '~' && inputtext[i + 2] == '~')
						{

							i += 2;
							break;
						}

						else
						{
							i++;
						}

					}
				}

				else
				{
					temp_word = temp_word + inputtext[i];

				}
			}

		}



		public static bool isPunc(char x)
		{
			bool check = false;
			foreach (var y in punc)
			{
				if (y == x)
				{
					check = true;
				}
			}
			return check;
		}
		public static bool isOp(char x)
		{
			bool check = false;
			foreach (var y in op)
			{
				if (y == x)
				{
					check = true;
				}
			}
			return check;
		}




	}
	/*if (ts[index].Item1.Equals("("))
							{
								index++;
									if (ts[index].Item1.Equals(")"))
									{
										index++;
										if (n())
										{
											if (ts[index].Item1.Equals("{"))
											{
												index++;
											if (ts[index].Item1.Equals("{"))
											{
												index++;
												if (n())
												{
													if (MST())
													{
														if (ts[index].Item1.Equals("}"))
														{
															index++;
															if (n())
															{
																if (c_body())
																{
																	if (ts[index].Item1.Equals("}"))
																	{
																		index++;
																		if (n())
																		{
																			if (defs())
																			{
																				return true;
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}

										}
									}
									}
								
							}*/
}

