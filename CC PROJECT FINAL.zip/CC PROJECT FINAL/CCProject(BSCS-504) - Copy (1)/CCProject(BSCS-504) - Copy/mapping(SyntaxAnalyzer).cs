﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CCProject_BSCS_504_
{
    class mapping_SyntaxAnalyzer_
    {
        List<Tokens> token = new List<Tokens>();
        static int index = 0;

        public mapping_SyntaxAnalyzer_(List<Tokens> t)
        {
            this.token = t;
        }

        public bool checkRule()
        {
            if (Start())
            {
                if (token[index].ValuePart == "$")
                {
                    Console.WriteLine("No syntax Error");
                    return true;
                }
            }
            Console.WriteLine($"RETURN FALSE {token[index].ClassPart} {token[index].Line}");
            return false;
        }
        public bool Start()
        {
            if (token[index].ClassPart == "public" || token[index].ClassPart == "sealed" || token[index].ClassPart == "struct" || token[index].ClassPart == "static" || token[index].ClassPart == "interface" || token[index].ClassPart == "abstract" || token[index].ClassPart == "class")
            {
                if (defstart())
                {
                    if (token[index].ClassPart == "{")
                    {
                        index++;

                        if (CBM())
                        {
                            if (class_body())
                            {
                                if (token[index].ClassPart.Equals("}"))
                                {
                                    index++;

                                    if (defend())
                                    {
                                        //if (token[index].ValuePart.Equals("$"))
                                        //{
                                            return true;

                                        //}
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }
        public bool static_abstract()
        {
            if (token[index].ClassPart.Equals("static"))
            {
                index++;
                return true;
            }
            else
            {
                if (token[index].ClassPart.Equals("abstract"))
                {
                    index++;
                    return true;
                }
            }
            return false;
        }

        public bool defstart()
        {
            if (token[index].ClassPart.Equals("public"))
            {
                index++;
                if (defstart1())
                {
                    if (defstart())
                    {
                        return true;
                    }
                }
            }

            else if (token[index].ClassPart == "sealed" || token[index].ClassPart == "struct" || token[index].ClassPart == "interface" || token[index].ClassPart == "static" || token[index].ClassPart == "abstract")
            {
                if (defstart())
                {
                    return true;
                }
            }
            else
            {
                if (token[index].ClassPart == "class")
                {
                    index++;
                    if (token[index].ClassPart == "ID")
                    {
                        index++;
                        //if (defstart11())
                        //{
                            return true;
                        //}
                    }
                }
            }
            return false;
        }

        public bool defstart1()
        {
            if (token[index].ClassPart.Equals("sealed"))
            {
                index++;

                if (token[index].ClassPart.Equals("class"))
                {
                    index++;

                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;

                        if (inheritance())
                        {
                            if (token[index].ClassPart.Equals("{"))
                            {
                                index++;

                                if (class_body())
                                {
                                    if (token[index].ClassPart.Equals("}"))
                                    {
                                        index++;
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            else if (token[index].ClassPart == "static" || token[index].ClassPart == "abtract")
            {
                if (defstart1111())
                {
                    return true;
                }
            }

            else if (token[index].ClassPart.Equals("struct"))
            {
                index++;

                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;

                    if (defstart11111())
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("interface"))
                {
                    index++;

                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;

                        if (inheritance())
                        {
                            if (token[index].ClassPart.Equals("{"))
                            {
                                index++;

                                if (class_body())
                                {
                                    if (token[index].ClassPart.Equals("}"))
                                    {
                                        index++;
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        public bool defstart11()
        {
            if (token[index].ClassPart.Equals(":") || token[index].ClassPart.Equals("{"))
            {
                if (inheritance())
                {
                    if (token[index].ClassPart.Equals("{"))
                    {
                        index++;
                        if (class_body())
                        {
                            if (token[index].ClassPart.Equals("}"))
                            {
                                index++;
                                return true;
                            }
                        }
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("public") ||
                    token[index].ClassPart.Equals("sealed") ||
                    token[index].ClassPart.Equals("struct") ||
                    token[index].ClassPart.Equals("interface") ||
                    token[index].ClassPart.Equals("static") ||
                    token[index].ClassPart.Equals("abstract") ||
                    token[index].ClassPart.Equals("class") ||
                    token[index].ClassPart.Equals("{"))
                {
                    return true;
                }
            }
            return false;
        }

        public bool defstart111()
        {
            if (token[index].ClassPart.Equals("for") ||
                token[index].ClassPart.Equals("if") ||
                token[index].ClassPart.Equals("do") ||
                token[index].ClassPart.Equals("break") ||
                token[index].ClassPart.Equals("return") ||
                token[index].ClassPart.Equals("continue") ||
                token[index].ClassPart.Equals("switch1") ||
                token[index].ClassPart.Equals("string") ||
                token[index].ClassPart.Equals("int") ||
                token[index].ClassPart.Equals("char") ||
                token[index].ClassPart.Equals("float") ||
                token[index].ClassPart.Equals("bool") ||
                token[index].ClassPart.Equals("++") ||
                token[index].ClassPart.Equals("--") ||
                token[index].ClassPart.Equals("ID") ||
                token[index].ClassPart.Equals("this") ||
                token[index].ClassPart.Equals("static") ||
                token[index].ClassPart.Equals("}"))
            {
                if (MST())
                {
                    if (token[index].ClassPart.Equals("}"))
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("interface"))
                {
                    return true;
                }
            }
            return false;
        }


        public bool defstart1111()
        {
            if (token[index].ClassPart.Equals("class"))
            {
                index++;

                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (defstart11())
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("struct"))
                {
                    index++;

                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        return true;
                    }
                }
            }
            return false;
        }
        public bool defstart11111()
        {
            if (token[index].ClassPart.Equals("for") ||
                token[index].ClassPart.Equals("if") ||
                token[index].ClassPart.Equals("do") ||
                token[index].ClassPart.Equals("break") ||
                token[index].ClassPart.Equals("return") ||
                token[index].ClassPart.Equals("continue") ||
                token[index].ClassPart.Equals("switch1") ||
                token[index].ClassPart.Equals("string") ||
                token[index].ClassPart.Equals("int") ||
                token[index].ClassPart.Equals("char") ||
                token[index].ClassPart.Equals("float") ||
                token[index].ClassPart.Equals("bool") ||
                token[index].ClassPart.Equals("++") ||
                token[index].ClassPart.Equals("--") ||
                token[index].ClassPart.Equals("ID") ||
                token[index].ClassPart.Equals("this") ||
                token[index].ClassPart.Equals("static") ||
                token[index].ClassPart.Equals("public") ||
                token[index].ClassPart.Equals("sealed") ||
                token[index].ClassPart.Equals("struct") ||
                token[index].ClassPart.Equals("interface") ||
                token[index].ClassPart.Equals("abstract") ||
                token[index].ClassPart.Equals("class"))
             {
                if (defstart11111())
                {
                    return true;
                }
            }

            else if (token[index].ClassPart.Equals("public") ||
                token[index].ClassPart.Equals("sealed") ||
                token[index].ClassPart.Equals("struct") ||
                token[index].ClassPart.Equals("interface") ||
                token[index].ClassPart.Equals("abstract") ||
                token[index].ClassPart.Equals("class"))
                {
                return true;
            }
            return false;
        }

        public bool defend()
        {
            if (token[index].ClassPart.Equals("public"))
            {
                index++;
                if (defend1())
                {
                    if (defend())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("interface") ||
        token[index].ClassPart.Equals("struct") ||
        token[index].ClassPart.Equals("static") ||
        token[index].ClassPart.Equals("abstract") ||
        token[index].ClassPart.Equals("sealed") ||
        token[index].ClassPart.Equals("class"))
            {
                if (defend1())
                {
                    if (defend())
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("$"))
                {
                  //  index++;
                    return true;
                }
            }
            return false;
        }


        public bool defend1()
        {
            if (token[index].ClassPart.Equals("static") ||
               token[index].ClassPart.Equals("abstract") ||
               token[index].ClassPart.Equals("sealed") ||
               token[index].ClassPart.Equals("class"))
            {
                if (class_mod())
                {
                    if (token[index].ClassPart.Equals("class"))
                    {
                        index++;

                        if (inheritance())
                        {
                            if (token[index].ClassPart.Equals("{"))
                            {
                                index++;


                                if (class_body())
                                {

                                    if (token[index].ClassPart.Equals("}"))
                                    {
                                        index++;
                                        return true;
                                    }

                                }
                            }
                        }
                    }
                }
            }

            else if (token[index].ClassPart.Equals("struct"))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;

                    if (MST())
                    {

                        if (token[index].ClassPart.Equals("}"))
                        {
                            index++;
                            return true;
                        }

                    }
                }

            }

            else if (token[index].ClassPart.Equals("interface"))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (inheritance())
                    {
                        if (token[index].ClassPart.Equals("{"))
                        {
                            index++;
                            if (class_body())
                            {
                                if (token[index].ClassPart.Equals("}"))
                                {
                                    index++;
                                    return true;
                                }
                            }
                        }

                    }
                }
            }
            return false;
        }

        public bool CBM()
        {
            if (token[index].ClassPart.Equals("void") ||
                (token[index].ClassPart.Equals("class")) ||
                (token[index].ClassPart.Equals("abstract")) ||
                (token[index].ClassPart.Equals("sealed")))
            {
                if (class_mod1())
                {
                    if (class_body2())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("static"))
            {
                index++;
                if (main1())
                {
                    return true;
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("public") ||
                    (token[index].ClassPart.Equals("private")) ||
                    (token[index].ClassPart.Equals("protected")))
                {
                    if (access_modifier1())
                    {
                        if (class_mod())
                        {
                            if (token[index].ClassPart.Equals("class"))
                            {
                                index++;
                                if (token[index].ClassPart.Equals("ID"))
                                {
                                    index++;
                                    if (inheritance())
                                    {
                                        if (token[index].ClassPart.Equals("{"))
                                        {
                                            index++;


                                            if (class_body())
                                            {

                                                if (token[index].ClassPart.Equals("}"))
                                                {
                                                    index++;
                                                    return true;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            }
            return false;
        }

        public bool class_body()
        {
            if (token[index].ClassPart.Equals("string") ||
                token[index].ClassPart.Equals("int") ||
                token[index].ClassPart.Equals("char") ||
                token[index].ClassPart.Equals("float") ||
                token[index].ClassPart.Equals("bool"))

            {
                if (DT())
                {
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        {
                            if (class_body1())
                            {
                                if (class_body())
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("abstract") ||
                token[index].ClassPart.Equals("static") ||
                token[index].ClassPart.Equals("sealed") ||
                token[index].ClassPart.Equals("void") ||
                token[index].ClassPart.Equals("class"))
            {
                if (class_mod())
                {
                    if (class_body2())
                    {
                        return true;
                    }
                }
            }

            else if (token[index].ClassPart.Equals("public") ||
                token[index].ClassPart.Equals("private") ||
                token[index].ClassPart.Equals("protected"))
            {
                if (access_modifier1())
                {
                    if (class_mod())
                    {
                        if (token[index].ClassPart.Equals("class"))
                        {
                            index++;
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (inheritance())
                                {
                                    if (token[index].ClassPart.Equals("{"))
                                    {
                                        index++;


                                        if (class_body())
                                        {

                                            if (token[index].ClassPart.Equals("}"))
                                            {
                                                index++;
                                                return true;
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("ID"))
            {
                index++;
                if (class_body1())
                {
                    if (class_body())
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("{") ||
                    (token[index].ClassPart.Equals("string")) ||
                    (token[index].ClassPart.Equals("int")) ||
                    (token[index].ClassPart.Equals("char")) ||
                    (token[index].ClassPart.Equals("float")) ||
                    (token[index].ClassPart.Equals("bool")) ||
                    (token[index].ClassPart.Equals("public")) ||
                    (token[index].ClassPart.Equals("private")) ||
                    (token[index].ClassPart.Equals("protected")) ||
                    (token[index].ClassPart.Equals("interface")) ||
                    (token[index].ClassPart.Equals("abstract")) ||
                    (token[index].ClassPart.Equals("static")) ||
                    (token[index].ClassPart.Equals("sealed")) ||
                    (token[index].ClassPart.Equals("void")) ||
                    (token[index].ClassPart.Equals("class")))
                {
                    return true;
                }
            }

            return false;
        }

        public bool class_body1()
        {
            if (token[index].ClassPart.Equals("=") ||
                 (token[index].ClassPart.Equals(",")) ||
                 (token[index].ClassPart.Equals(";")))
            {
                if (initialize())
                {
                    if (list())
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    {
                        if (token[index].ClassPart.Equals("("))
                        {
                            index++;
                            if (parameter())
                            {
                                if (token[index].ClassPart.Equals(")"))
                                {
                                    index++;
                                    if (body())
                                    {
                                        if (token[index].ClassPart.Equals("}"))
                                        {
                                            index++;
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        public bool class_body2()
        {
            if (token[index].ClassPart.Equals("void"))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (class_body1())
                    {
                        return true;
                    }
                }

            }
            else if (token[index].ClassPart.Equals("class"))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    if (inheritance())
                    {
                        if (token[index].ClassPart.Equals("{"))
                        {
                            index++;


                            if (class_body())
                            {

                                if (token[index].ClassPart.Equals("}"))
                                {
                                    index++;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool main1()
        {
            if (token[index].ClassPart.Equals("void"))
            {
                index++;
                if (main2())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("class"))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (inheritance())
                    {
                        if (token[index].ClassPart.Equals("{"))
                        {
                            index++;


                            if (class_body())
                            {

                                if (token[index].ClassPart.Equals("}"))
                                {
                                    index++;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool main2()
        {
            if (token[index].ClassPart.Equals("main"))
            {
                index++;
                //if (token[index].ClassPart.Equals("{"))
                //{
                //    index++;
                    if (body())
                    {
                        if (token[index].ClassPart.Equals("}"))
                        {
                            index++;
                            return true;
                        }
                    }
              //  }
            }
            else
            {
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (class_body1())
                    {
                        if (main1())
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public bool body()
        {
            if (token[index].ClassPart.Equals(";"))
            {
                index++;
            }
            else
            {
                if (token[index].ClassPart.Equals("{"))
                {
                    index++;
                    if (MST())
                    {
                        return true;
                    }
                }
            }
            return false;
        }


        public bool body1()
        {
            if (token[index].ClassPart.Equals("for") ||
                (token[index].ClassPart.Equals("if")) ||
                (token[index].ClassPart.Equals("do")) ||
                (token[index].ClassPart.Equals("break")) ||
                (token[index].ClassPart.Equals("return")) ||
                (token[index].ClassPart.Equals("continue")) ||
                (token[index].ClassPart.Equals("switch1")) ||
                (token[index].ClassPart.Equals("static")) ||
                (token[index].ClassPart.Equals("string")) ||
                (token[index].ClassPart.Equals("int")) ||
                (token[index].ClassPart.Equals("char")) ||
                (token[index].ClassPart.Equals("bool")) ||
                (token[index].ClassPart.Equals("++")) ||
                (token[index].ClassPart.Equals("--")) ||
                (token[index].ClassPart.Equals("ID")) ||
                (token[index].ClassPart.Equals("this")))
            {
                if (SST())
                {
                    return true;
                }
            }
            else
            {
                if (token[index].ClassPart.Equals(";") ||
                    (token[index].ClassPart.Equals("{")))
                {
                    if (body())
                    {
                        if (token[index].ClassPart.Equals("}"))
                        {
                            index++;
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public bool MST()
        {
            if (token[index].ClassPart.Equals("}") ||
                (token[index].ClassPart.Equals(";")))
            {
                index++;
                return true;
            }
            else
            {
                if (token[index].ClassPart.Equals("for") ||
                (token[index].ClassPart.Equals("if")) ||
                (token[index].ClassPart.Equals("do")) ||
                (token[index].ClassPart.Equals("break")) ||
                (token[index].ClassPart.Equals("return")) ||
                (token[index].ClassPart.Equals("continue")) ||
                (token[index].ClassPart.Equals("switch1")) ||
                (token[index].ClassPart.Equals("static")) ||
                (token[index].ClassPart.Equals("string")) ||
                (token[index].ClassPart.Equals("int")) ||
                (token[index].ClassPart.Equals("char")) ||
                (token[index].ClassPart.Equals("bool")) ||
                (token[index].ClassPart.Equals("++")) ||
                (token[index].ClassPart.Equals("--")) ||
                (token[index].ClassPart.Equals("ID")) ||
                (token[index].ClassPart.Equals("this")))
                {
                    if (SST())
                    {
                        if (MST())
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        //public bool access_modifier()
        //{
        //    if (token[index].ClassPart.Equals("public"))
        //    {
        //        index++;
        //        return true;
        //    }
        //    else if (token[index].ClassPart.Equals("private"))
        //    {
        //        index++;
        //        return true;
        //    }
        //    else if (token[index].ClassPart.Equals("protected"))
        //    {
        //        index++;
        //        return true;
        //    }
        //    else
        //    {
        //        if (token[index].ClassPart.Equals("static") ||
        //            token[index].ClassPart.Equals("abstract") ||
        //            token[index].ClassPart.Equals("sealed") ||
        //            token[index].ClassPart.Equals("class") )
        //        {

        //            return true;
        //        }
        //    }
        //    return false;
        //}

        public bool access_modifier1()
        {
            if (token[index].ClassPart.Equals("public"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("private"))
            {
                index++;
                return true;
            }
            else
            {
                if (token[index].ClassPart.Equals("protected"))
                {
                    index++;
                    return true;
                }
            }
            return false;
        }

        public bool class_mod()
        {
            if (token[index].ClassPart.Equals("static"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("abstract"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("sealed"))
            {
                index++;
                return true;
            }
            else
            {
                if (token[index].ClassPart.Equals("class") ||
                    (token[index].ClassPart.Equals("void")) ||
                    (token[index].ClassPart.Equals("class")))
                {
                    return true;
                }
            }
            return false;
        }


        public bool class_mod1()
        {
            if (token[index].ClassPart.Equals("abstract"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("sealed"))
            {
                index++;
                return true;
            }
            else
            {
                if (token[index].ClassPart.Equals("class") ||
                    (token[index].ClassPart.Equals("void")))

                {

                    return true;
                }
            }
            return false;
        }
        public bool return_type()
        {
            if (token[index].ClassPart.Equals("void"))
            {
                index++;
                return true;

            }
            else
            {
                if ((token[index].ClassPart.Equals("string") ||
                    (token[index].ClassPart.Equals("int")) ||
                    (token[index].ClassPart.Equals("char")) ||
                    (token[index].ClassPart.Equals("float")) ||
                    (token[index].ClassPart.Equals("bool"))))
                {
                    return true;
                }
            }
            return false;
        }

        public bool DT()
        {
            if (token[index].ClassPart.Equals("string"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("int"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("char"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("float"))
            {
                index++;
                return true;
            }
            else
            {
                if (token[index].ClassPart.Equals("bool"))
                {
                    index++;
                    return true;
                }
            }
            return false;
        }

        public bool inheritance()
        {
            if (token[index].ClassPart.Equals("{"))
            {
                return true;
            }
            else
            {
                if (token[index].ClassPart.Equals(":"))
                {
                    index++;
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        if (ID())
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        public bool ID()
        {
            if (token[index].ClassPart.Equals(","))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (ID())
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("(") ||
                     (token[index].ClassPart.Equals("{")))
                {
                    return true;
                }
            }
            return false;
        }


        public bool fn_def()
        {
            if (token[index].ClassPart.Equals("static"))
            {
                index++;
                if (return_type())
                {
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("("))
                        {
                            index++;
                            if (parameter())
                            {
                                if (token[index].ClassPart.Equals(")"))
                                {
                                    index++;
                                    if (body())
                                    {
                                        if (token[index].ClassPart.Equals("}"))
                                        {
                                            index++;
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        public bool parameter()
        {
            if (token[index].ClassPart.Equals("string") ||
                (token[index].ClassPart.Equals("int")) ||
                (token[index].ClassPart.Equals("char")) ||
                (token[index].ClassPart.Equals("float")) ||
                (token[index].ClassPart.Equals("bool")))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (p1())
                    {
                        return true;
                    }
                }

            }
            return false;
        }

        public bool p1()
        {
            if (token[index].ClassPart.Equals("="))
            {
                index++;
                if (OE())
                {
                    if (p2())
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (p2())
                {
                    return true;
                }
            }
            return false;
        }

        public bool p2()
        {
            if (token[index].ClassPart.Equals(","))
            {
                index++;
                if (DT())
                {
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        if (p1())
                        {
                            return true;
                        }
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals(")"))
                {
                   // index++;
                    return true;
                }
            }
            return false;
        }

        public bool switch1()
        {
            if (token[index].ClassPart.Equals("switch1"))
            {
                index++;
                if (token[index].ClassPart.Equals("("))
                {
                    index++;
                    if (OE())
                    {
                        if (token[index].ClassPart.Equals(")"))
                        {
                            index++;
                            {
                                if (token[index].ClassPart.Equals("{"))
                                {
                                    index++;
                                    if (case_default())
                                    {
                                        if (token[index].ClassPart.Equals("}"))
                                        {
                                            index++;
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
            return false;
        }

        public bool default1()
        {
            if (token[index].ClassPart.Equals("default"))
            {
                index++;
                if (token[index].ClassPart.Equals(":"))
                {
                    index++;
                    if (body1())
                    {
                        if (token[index].ClassPart.Equals("break"))
                            index++;
                        if (token[index].ClassPart.Equals(";"))
                        {
                            index++;
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public bool case_default()
        {
            if (token[index].ClassPart.Equals("default"))
            {
                if (default1())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("case"))
            {
                index++;
                if (case_default1())
                {
                    return true;
                }
            }
            return false;
        }

        public bool case_default1()
        {
            if (token[index].ClassPart.Equals("int-const") || (token[index].ClassPart.Equals("string-const")) || (token[index].ClassPart.Equals("float-const")))
            {
                //index++;
                if (token[index].ClassPart.Equals(":"))
                {
                    index++;
                    if (body1())
                    {
                        if (token[index].ClassPart.Equals("breal"))
                        {
                            index++;
                            if (token[index].ClassPart.Equals(";"))
                            {
                                index++;
                                return true;
                            }
                        }
                    }
                }
            }
            else if (default1())
            {
                return true;
            }
            return false;
        }

        public bool this1()
        {
            if (token[index].ClassPart.Equals("this"))
            {
                index++;
                if (token[index].ClassPart.Equals("."))
                {
                    index++;
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("ID"))
            {
               // index++;
                return true;

            }
            return false;

        }

        public bool OE()
        {
            if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") || token[index].ClassPart.Equals("float-const") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("!") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this"))
            {
                if (OE1())
                {
                    return true;
                }
            }
            return false;

        }

        public bool OE1()
        {
            if (token[index].ClassPart.Equals("||"))
            {
                index++;
                if (AE())
                {
                    if (OE1())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals(")") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals(","))
            {
                index++;
                return true;

            }
            return false;
        }

        public bool AE()
        {
            if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") || token[index].ClassPart.Equals("float-const") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("!") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this"))
            {
                //index++;
                if (return_type())
                {
                    if (AE1())
                    {
                        return true;
                    }
                }
            }
            return false;


        }

        public bool AE1()
        {
            if (token[index].ClassPart.Equals("&&"))
            {
                index++;
                if (RE())
                {
                    if (AE1())
                    {
                        return true;

                    }
                }
            }
            else if (token[index].ClassPart.Equals("||") || token[index].ClassPart.Equals(")") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals(","))
            {
                //index++;
                return true;
            }
            return false;

        }

        public bool RE()
        {
            if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") || token[index].ClassPart.Equals("float-const") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("!") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this"))
            {
                //index++;
                if (RE1())
                {
                    return true;

                }
            }
            return false;
        }

        public bool RE1()
        {
            if (token[index].ClassPart.Equals("==") || token[index].ClassPart.Equals("!=") || token[index].ClassPart.Equals(">") || token[index].ClassPart.Equals("<") || token[index].ClassPart.Equals(">=") || token[index].ClassPart.Equals("<="))
            {
                index++;
                if (SE())
                {
                    if (RE1())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("&&") || token[index].ClassPart.Equals("||") || token[index].ClassPart.Equals(")") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals(","))
            {
                //index++;
                return true;

            }
            return false;
        }

        public bool SE()
        {
            if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") || token[index].ClassPart.Equals("float-const") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("!") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this"))
            {
               // index++;
                if (SE1())
                {
                    return true;
                }

            }
            return false;
        }
        public bool SE1()
        {
            if (token[index].ClassPart.Equals("<<") || token[index].ClassPart.Equals(">>"))
            {
                index++;
                if (E())
                {
                    if (SE1())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("&&") || token[index].ClassPart.Equals("||") || token[index].ClassPart.Equals(")") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals(",") || token[index].ClassPart.Equals("==") || token[index].ClassPart.Equals("!=") || token[index].ClassPart.Equals(">") || token[index].ClassPart.Equals("<") || token[index].ClassPart.Equals(">=") || token[index].ClassPart.Equals("<="))
            {
                //index++;
                return true;
            }
            return false;

        }

        public bool E()
        {
            if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") || token[index].ClassPart.Equals("float-const") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("!") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this"))
            {
               // index++;
                if (T())
                {
                    if (E1())
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public bool E1()
        {
            if (token[index].ClassPart.Equals("arithmetic-operator"))
            {
                index++;
                if (T())
                {
                    if (E1())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("&&") || token[index].ClassPart.Equals("||") || token[index].ClassPart.Equals(")") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals(",") || token[index].ClassPart.Equals("==") || token[index].ClassPart.Equals("!=") || token[index].ClassPart.Equals(">") || token[index].ClassPart.Equals("<") || token[index].ClassPart.Equals(">=") || token[index].ClassPart.Equals("<=") || token[index].ClassPart.Equals("<<") || token[index].ClassPart.Equals(">>"))
            {
                //index++;
                return true;
            }
            return false;
        }
        public bool T()
        {
            if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") || token[index].ClassPart.Equals("float-const") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("!") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this"))
            {
               // index++;
                if (F())
                {
                    if (T1())
                    {
                        return true;
                    }
                }
            } return false;

        }
        public bool T1()
        {
            if (token[index].ClassPart.Equals("arithmetic-operator"))
            {
                index++;
                if (F())
                {
                    if (T1())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("&&") || token[index].ClassPart.Equals("||") || token[index].ClassPart.Equals(")") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals(",") || token[index].ClassPart.Equals("==") || token[index].ClassPart.Equals("!=") || token[index].ClassPart.Equals(">") || token[index].ClassPart.Equals("<") || token[index].ClassPart.Equals(">=") || token[index].ClassPart.Equals("<=") || token[index].ClassPart.Equals("<<") || token[index].ClassPart.Equals(">>") || token[index].ClassPart.Equals("+") || token[index].ClassPart.Equals("-"))
            {
               // index++;
                return true;

            }
            return false;
        }

        public bool F()
        {
            if (token[index].ClassPart.Equals("ID"))
            {
                index++;
                if (F1())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-cpnst") || token[index].ClassPart.Equals("float-const"))
            {
               // index++;
                return true;

            }
            else if (token[index].ClassPart.Equals("("))
            {
                index++;
                if (OE())
                {
                    if (token[index].ClassPart.Equals(")"))
                    {
                        index++;
                        return true;
                    }
                }

            }
            else if (token[index].ClassPart.Equals("!"))
            {
                index++;
                if (F())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("inc_dec"))
            {
                //index++;
                if (this1())
                {
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        if (Z2())
                        {
                            return true;
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("this"))
            {
                index++;
                if (token[index].ClassPart.Equals("."))
                {
                    index++;
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        if (Z())
                        {
                            if (token[index].ClassPart.Equals(";"))
                            {
                                index++;
                                return true;

                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool F1()
        {
            if (token[index].ClassPart.Equals(".") || token[index].ClassPart.Equals("[") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--"))
            {
                //index++;
                if (token[index].ClassPart.Equals(";"))
                {
                    index++;
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("&&") || token[index].ClassPart.Equals("||") || token[index].ClassPart.Equals(")") || token[index].ClassPart.Equals("=") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals(",") || token[index].ClassPart.Equals("==") || token[index].ClassPart.Equals("!=") || token[index].ClassPart.Equals(">") || token[index].ClassPart.Equals("<") || token[index].ClassPart.Equals(">=") || token[index].ClassPart.Equals("<=") || token[index].ClassPart.Equals("<<") || token[index].ClassPart.Equals(">>") || token[index].ClassPart.Equals("+") || token[index].ClassPart.Equals("-") || token[index].ClassPart.Equals("*") || token[index].ClassPart.Equals("/"))
            {
                //index++;
                return true;
            }
            return false;

        }
        public bool X11()
        {
            if (token[index].ClassPart.Equals("."))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (X())
                    {
                        return true;

                    }
                }
            }
            else if (token[index].ClassPart.Equals("["))
            {
                index++;
                if (token[index].ClassPart.Equals("int-const"))
                {
                    index++;
                    if (token[index].ClassPart.Equals("."))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("ID"))
                        {
                            index++;
                            if (X())
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("("))
            {
                index++;
                if (parameter())
                {
                    if (token[index].ClassPart.Equals("."))
                    {
                        if (token[index].ClassPart.Equals("ID"))
                        {
                            if (X())
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool X()
        {
            if (token[index].ClassPart.Equals("."))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (X())
                    {
                        return true;

                    }
                }
            }
            else if (token[index].ClassPart.Equals("["))
            {
                index++;
                if (token[index].ClassPart.Equals("int-const"))
                {
                    index++;
                    if (token[index].ClassPart.Equals("."))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("ID"))
                        {
                            index++;
                            if (X())
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("("))
            {
                index++;
                if (parameter())
                {
                    if (token[index].ClassPart.Equals("."))
                    {
                        if (token[index].ClassPart.Equals("ID"))
                        {
                            if (X())
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("="))
            {
                index++;
                if (OE())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("inc_dec"))
            {
                //index++;
                return true;
            }
            return false;
        }

        public bool for_st()
        {
            if (token[index].ClassPart.Equals("for"))
            {
                index++;
                if (token[index].ClassPart.Equals("("))
                {
                    index++;
                    if (C1())
                    {
                        if (C2())
                        {
                            if (token[index].ClassPart.Equals(";"))
                            {
                                index++;
                                if (C3())
                                {
                                    if (token[index].ClassPart.Equals(")"))
                                    {
                                        index++;
                                        if (body1())
                                        {
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
            return false;
        }
        public bool C1()
        {
            if (token[index].ClassPart.Equals(";"))
            {
                index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("int") || token[index].ClassPart.Equals("float") || token[index].ClassPart.Equals("bool") || token[index].ClassPart.Equals("char") || token[index].ClassPart.Equals("string"))
            {
               // index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("this") || token[index].ClassPart.Equals("ID"))
            {
             //   index++;
                return true;
            }
            return false;
        }

        public bool C2()
        {
            if (token[index].ClassPart.Equals("ID") || token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") || token[index].ClassPart.Equals("float-const") || token[index].ClassPart.Equals("(") || token[index].ClassPart.Equals("!") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this"))
            {
               // index++;
                if (OE())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals(";")) {
               // index++;
                return true;
            }
            return false;
        }

        public bool C3()
        {
            if (token[index].ClassPart.Equals("this") || token[index].ClassPart.Equals("ID"))
            {
              //  index++;
                if (this1())
                {
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        if (X())
                        {
                            return true;
                        }
                    }
                }

            }
            else if (token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--"))
            {
                //index++;
                if (inc_dec())
                {
                    if (this1())
                    {
                        if (token[index].ClassPart.Equals("ID")) 
                        {
                            index++;
                            if (X11())
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals(")"))
            {
              //  index++;
                return true;

            }
            return false;

        }
        //public bool inc_dec() //sohaib
        //{
        //    if (token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--"))
        //    {
        //        index++;
        //        return true;
        //    }
        //    return false;
        //}
        public bool do_while_st()
        {
            if (token[index].ClassPart.Equals("do"))
            {
                index++;
                if (token[index].ClassPart.Equals("{"))
                {
                    index++;
                    if (semicolon())
                    {
                        if (MST())
                        {
                            if (semicolon())
                            {
                                if (token[index].ClassPart.Equals("}"))
                                {
                                    index++;
                                    if (token[index].ClassPart.Equals("while"))
                                    {
                                        index++;
                                        if (token[index].ClassPart.Equals("("))
                                        {
                                            index++;
                                            if (OE())
                                            {
                                                if (token[index].ClassPart.Equals(")"))
                                                {
                                                    index++;
                                                    return true;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool semicolon()
        {
            if (token[index].ClassPart.Equals(";"))
            {
                index++;
                if (semicolon())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("for") || token[index].ClassPart.Equals("if") || token[index].ClassPart.Equals("do") || token[index].ClassPart.Equals("break") || token[index].ClassPart.Equals("return") || token[index].ClassPart.Equals("continue") || token[index].ClassPart.Equals("switch") || token[index].ClassPart.Equals("static") || token[index].ClassPart.Equals("int") || token[index].ClassPart.Equals("string") || token[index].ClassPart.Equals("bool") || token[index].ClassPart.Equals("char") || token[index].ClassPart.Equals("float") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals("}"))
            {
               // index++;
                return true;
            }
            return false;
        }

        public bool if_else()
        {
            if (token[index].ClassPart.Equals("if"))
            {
                index++;
                if (token[index].ClassPart.Equals("("))
                {
                    index++;
                    if (OE())
                    {
                        if (token[index].ClassPart.Equals(")"))
                        {
                            index++;
                            if (body1())
                            {
                                if (else1())
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        public bool else1()
        {
            if (token[index].ClassPart.Equals("else"))
            {
                index++;
                if (body1())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("for") || token[index].ClassPart.Equals("if") || token[index].ClassPart.Equals("do") || token[index].ClassPart.Equals("break") || token[index].ClassPart.Equals("return") || token[index].ClassPart.Equals("continue") || token[index].ClassPart.Equals("switch") || token[index].ClassPart.Equals("static") || token[index].ClassPart.Equals("int") || token[index].ClassPart.Equals("string") || token[index].ClassPart.Equals("bool") || token[index].ClassPart.Equals("char") || token[index].ClassPart.Equals("float") || token[index].ClassPart.Equals("++") || token[index].ClassPart.Equals("--") || token[index].ClassPart.Equals("this") || token[index].ClassPart.Equals(";") || token[index].ClassPart.Equals("}"))
            {
               // index++;
                return true;
            }
            return false;
        }
        public bool constant()
        {
            if (token[index].ClassPart.Equals("int-const") || token[index].ClassPart.Equals("string-const") | token[index].ClassPart.Equals("char-const"))
            {
                index++;
                return true;
            }
            return false;
        }
        public bool L()
        {
            if (token[index].ClassPart.Equals("["))
            {
                index++;
                if (I())
                {
                    if (token[index].ClassPart.Equals("]"))
                    {
                        index++;
                        {
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (AE1())
                                {
                                    if (token[index].ClassPart.Equals(";"))
                                    {
                                        index++;
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (initialize())
                    {
                        if (list())
                        {
                            return true;
                        }
                    }
                }
            }
            return false;

        }
        public bool A1()
        {
            if (token[index].ClassPart.Equals("="))
            {
                index++;
                if (A1())
                {
                    return true;
                }
            }
            return false;
        }
        public bool A11() //marium
        {
            if (token[index].ClassPart.Equals("{"))
            {
                index++;
                if (A2())
                {
                    return true;
                }
            }
            else if ((token[index].ClassPart.Equals("new")))
            {
                index++;
                if (DT())
                {
                    if (token[index].ClassPart.Equals("["))
                    {
                        index++;
                        if (N())
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public bool A2()
        {
            if (token[index].ClassPart.Equals("int_constant") ||
                token[index].ClassPart.Equals("string_constant") ||
                    token[index].ClassPart.Equals("float_constant"))
            {
                //index++;

                if (constant())
                {
                    if (A21())
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public bool A21()
        {
            if ((token[index].ClassPart.Equals(",")))
            {
                index++;
                if (A2())
                {
                    return true;
                }
            }
            else if ((token[index].ClassPart.Equals("}")))
            {
                index++;
                return true;
            }
            return false;
        }
        public bool I()
        {
            if ((token[index].ClassPart.Equals("int_const")))
            {
                index++;
                return true;
            }
            else if ((token[index].ClassPart.Equals("]")))
            {
                //index++;
                return true;
            }
            return false;
        }
        public bool N()
        {
            if ((token[index].ClassPart.Equals("int_constant")))
            {
                index++;
                if (N1())
                {
                    return true;
                }
            }
            else if ((token[index].ClassPart.Equals("]")))
            {
               // index++;
                if (N1())
                {
                    return true;
                }
            }
            return false;
        }
        public bool N1()
        {
            if ((token[index].ClassPart.Equals("]")))
            {
                index++;
                if (N11())
                {
                    return true;
                }
            }
            return false;
        }
        public bool N11()
        {
            if ((token[index].ClassPart.Equals("{")))
            {
                index++;
                if (A2())
                {
                    if ((token[index].ClassPart.Equals("}")))
                    {
                        index++;
                        return true;
                    }
                }
            }
            else if ((token[index].ClassPart.Equals(";")))
            {
               // index++;
                return true;
            }
            return false;


        }
        public bool dec()
        {
            if (token[index].ClassPart.Equals("int_constant") ||
                 token[index].ClassPart.Equals("string_constant") ||
                     token[index].ClassPart.Equals("float_constant"))
            {
               // index++;
                if (DT())
                {
                    if ((token[index].ClassPart.Equals("ID")))
                    {
                        index++;
                        if (initialize())
                        {
                            if (list())
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        public bool initialize()
        {
            if (token[index].ClassPart.Equals(";") ||
               token[index].ClassPart.Equals(","))
            {
               // index++;
                return true;
            }
            else if (token[index].ClassPart.Equals("="))
            {
                index++;
                if (OE())
                {
                    return true;
                }
            }
            return false;
        }

        //public bool A1() //marium
        //{
        //    if (token[index].ClassPart.Equals("="))
        //    {
        //        index++;
        //        if (A1())
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        //public bool A11()
        //{
        //    if (token[index].ClassPart.Equals("{"))
        //    {
        //        index++;
        //        if (A2())
        //        {
        //            return true;
        //        }
        //    }
        //    else if ((token[index].ClassPart.Equals("new")))
        //    {
        //        index++;
        //        if (DT())
        //        {
        //            if (token[index].ClassPart.Equals("["))
        //            {
        //                index++;
        //                if (N())
        //                {
        //                    return true;
        //                }
        //            }
        //        }
        //    }
        //    return false;
        //}

        //public bool A2()
        //{
        //    if (token[index].ClassPart.Equals("int_constant") ||
        //        token[index].ClassPart.Equals("string_constant") ||
        //            token[index].ClassPart.Equals("float_constant"))
        //    {


        //        if (constant())
        //        {
        //            if (A21())
        //            {
        //                return true;
        //            }
        //        }
        //    }
        //    return false;
        //}
        //public bool A21()
        //{
        //    if ((token[index].ClassPart.Equals(",")))
        //    {
        //        index++;
        //        if (A2())
        //        {
        //            return true;
        //        }
        //    }
        //    else if ((token[index].ClassPart.Equals("}")))
        //    {
        //        return true;
        //    }
        //    return false;
        //}
        //public bool I()
        //{
        //    if ((token[index].ClassPart.Equals("int_const")))
        //    {
        //        index++;
        //        return true;
        //    }
        //    else if ((token[index].ClassPart.Equals("]")))
        //    {
        //        index++;
        //        return true;
        //    }
        //    return false;
        //}
        //public bool N()
        //{
        //    if ((token[index].ClassPart.Equals("int_constant")))
        //    {
        //        index++;
        //        if (N1())
        //        {
        //            return true;
        //        }
        //    }
        //    else if ((token[index].ClassPart.Equals("]")))
        //    {
        //        index++;
        //        if (N1())
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        //public bool N1()
        //{
        //    if ((token[index].ClassPart.Equals("]")))
        //    {
        //        index++;
        //        if (N11())
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        //public bool N11()
        //{
        //    if ((token[index].ClassPart.Equals("{")))
        //    {
        //        index++;
        //        if (A2())
        //        {
        //            if ((token[index].ClassPart.Equals("}")))
        //            {
        //                index++;
        //                return true;
        //            }
        //        }
        //    }
        //    else if ((token[index].ClassPart.Equals(";")))
        //    {
        //        index++;
        //        return true;
        //    }
        //    return false;


//        }
        //public bool dec()
        //{
        //    if (token[index].ClassPart.Equals("int_constant") ||
        //         token[index].ClassPart.Equals("string_constant") ||
        //             token[index].ClassPart.Equals("float_constant"))
        //    {

        //        if (DT())
        //        {
        //            if ((token[index].ClassPart.Equals("ID")))
        //            {
        //                index++;
        //                if (initialize())
        //                {
        //                    if (list())
        //                    {
        //                        return true;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    return false;
        //}
        //public bool initialize()
        //{
        //    if (token[index].ClassPart.Equals(";") ||
        //       token[index].ClassPart.Equals(","))
        //    {

        //        return true;
        //    }
        //    else if (token[index].ClassPart.Equals("="))
        //    {
        //        index++;
        //        if (OE())
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        public bool list()
        {
            if ((token[index].ClassPart.Equals(";")))
            {
                return true;
            }
            else if ((token[index].ClassPart.Equals(",")))
            {
                index++;
                if ((token[index].ClassPart.Equals("ID")))
                {
                    index++;
                    if (initialize())
                    {
                        if (list())
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        public bool Object()
        {
            if ((token[index].ClassPart.Equals("ID")))
            {
                index++;
                if ((token[index].ClassPart.Equals("=")))
                {
                    index++;
                          if ((token[index].ClassPart.Equals("new")))
                    {
                        index++;
                        if (class_name())
                        {
                            if ((token[index].ClassPart.Equals("(")))
                            {
                                index++;
                                if ((token[index].ClassPart.Equals(")")))
                                {
                                    index++;
                                    return true;
                                }
                            }
                        }

                    }
                }
            }
            else if (token[index].ClassPart.Equals(".") ||
                     token[index].ClassPart.Equals("[") ||
                     token[index].ClassPart.Equals("(") ||
                     token[index].ClassPart.Equals("=") ||
                     token[index].ClassPart.Equals("++") ||
                     token[index].ClassPart.Equals("--"))
            {

                if (Z())
                {
                    return true;
                }
            }
            else if ((token[index].ClassPart.Equals("=")))
            {
                index++;
                if (OE())
                {
                    return true;
                }
            }
            return false;
        }

        public bool class_name()
        {
            if ((token[index].ClassPart.Equals("ID")))
            {
                index++;
                return true;
            }
            return false;
        }
        public bool Z()
        {
            if ((token[index].ClassPart.Equals(".")))
            {
                index++;
                if ((token[index].ClassPart.Equals("ID")))
                {
                    index++;
                    if (R1())
                    {
                        return true;
                    }
                }
            }
            else if ((token[index].ClassPart.Equals("[")))
            {
                index++;
                if ((token[index].ClassPart.Equals("int_constant")))
                {
                    index++;
                    if ((token[index].ClassPart.Equals("]")))
                    {
                        index++;
                        if ((token[index].ClassPart.Equals(".")))
                        {
                            index++;
                            if ((token[index].ClassPart.Equals("ID")))
                            {
                                index++;
                                if (R1())
                                {
                                    return true;
                                }
                            }

                        }
                    }


                }
            }
            else if ((token[index].ClassPart.Equals("(")))
            {
                index++;
                if (parameter())
                {
                    if ((token[index].ClassPart.Equals(")")))
                        index++;
                    if (R2())
                    {
                        return true;
                    }
                }
            }

            else if ((token[index].ClassPart.Equals("=")) ||
                (token[index].ClassPart.Equals("++")) || (token[index].ClassPart.Equals("--")))
            {
                //index++;
                return true;
            }
            return false;
        }

        public bool assign_st()
        {
            if ((token[index].ClassPart.Equals("this")) ||
               (token[index].ClassPart.Equals("ID")))
            {
                if (this1())
                {
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        if (X1())
                        {
                            if (initialize())
                            {
                                if (list())
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        /******/
        public bool inc_dec() //marium
        {
            if (token[index].ClassPart.Equals("inc_dec"))
            {
                index++;
                return true;
            }
            return false;
        }

        public bool SST()
        {
            if (token[index].ClassPart.Equals("for"))
            {
                if (for_st())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("if"))
            {
                if (if_else())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("do"))
            {
                if (do_while_st())
                {
                    if (token[index].ClassPart.Equals(";"))
                    {
                        index++;
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("continue"))
            {
                index++;
                if (token[index].ClassPart.Equals(";"))
                {
                    index++;
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("break"))
            {
                index++;
                if (token[index].ClassPart.Equals(";"))
                {
                    index++;
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("return"))
            {
                index++;
                if (OE())
                {
                    if (token[index].ClassPart.Equals(";"))
                    {
                        index++;
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("switch"))
            {
                if (switch1())
                {
                    if (token[index].ClassPart.Equals("}"))
                    {
                        index++;
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("ID"))
            {
                index++;
                if (Object())
                {
                    if (token[index].ClassPart.Equals(";"))
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("this"))
            {
                index++;
                if (token[index].ClassPart.Equals("."))
                {
                    index++;
                    if (token[index].ClassPart.Equals("ID"))
                    {
                        index++;
                        if (K())
                        {
                            if (token[index].ClassPart.Equals(";"))
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("inc_dec"))
            {
                if (inc_dec())
                {
                    if (this1())
                    {
                        if (token[index].ClassPart.Equals("ID"))
                        {
                            index++;
                            if (Z2())
                            {
                                if (token[index].ClassPart.Equals(";"))
                                {
                                    index++;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("string") ||
                     token[index].ClassPart.Equals("int") ||
                     token[index].ClassPart.Equals("char") ||
                     token[index].ClassPart.Equals("bool") ||
                     token[index].ClassPart.Equals("float"))
            {
                if (DT())
                {
                    if (L())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("static"))
            {
                if (fn_def())
                {
                    if (token[index].ClassPart.Equals("}"))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public bool K()
        {
            if (token[index].ClassPart.Equals(".") ||
                     token[index].ClassPart.Equals("[") ||
                     token[index].ClassPart.Equals("(") ||
                     token[index].ClassPart.Equals(";"))
            {
                if (Z2())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("="))
            {
                index++;
                if (OE())
                {
                    return true;
                }
            }
            return false;
        }
        public bool R1()
        {
            if (token[index].ClassPart.Equals("."))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (Z())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("["))
            {
                index++;
                if (token[index].ClassPart.Equals("int_const"))
                {
                    index++;
                    if (token[index].ClassPart.Equals("]"))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("."))
                        {
                            index++;
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (Z())
                                {
                                    return true;
                                }
                            }
                        }
                    }

                }
            }
            else if (token[index].ClassPart.Equals("("))
            {
                index++;
                if (parameter())
                {
                    if (token[index].ClassPart.Equals(")"))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("."))
                        {
                            index++;
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (Z())
                                {
                                    return true;
                                }

                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals(";"))
            {
               // index++;
                return true;
            }
            return false;
        }
        public bool R2()
        {
            if (token[index].ClassPart.Equals("."))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (B())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals(";"))
            {
               // index++;
                return true;
            }
            return false;
        }
        public bool B()
        {
            if (token[index].ClassPart.Equals(".") ||
               token[index].ClassPart.Equals("[") ||
               token[index].ClassPart.Equals("(") ||
               token[index].ClassPart.Equals(";"))
            {
                if (Z2())
                {
                    return true;
                }
            }
            else if (token[index].ClassPart.Equals("=") ||
                token[index].ClassPart.Equals("++") ||
                token[index].ClassPart.Equals("--"))
            {
                if (X1())
                {
                    return true;
                }
            }
            return false;

        }
        public bool X1()
        {
            if (token[index].ClassPart.Equals("="))
            {
                index++;
                if (OE())
                {
                    return true;
                }
            }

            else if (token[index].ClassPart.Equals("++")||
                (token[index].ClassPart.Equals("--")))
            {
                if (inc_dec())
                {
                    return true;
                }
            }
            return false;
        }
        public bool Z2()
        {
            if (token[index].ClassPart.Equals("."))
            {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (R11())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("["))
            {
                index++;
                if (token[index].ClassPart.Equals("int_const"))
                {
                    index++;
                    if (token[index].ClassPart.Equals("]"))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("."))
                        {
                            index++;
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (R11())
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("("))
            {
                index++;
                if (parameter())
                {
                    if (token[index].ClassPart.Equals(")"))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("."))
                        {
                            index++;
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (R11())
                                {
                                    return true;
                                }

                            }
                        }
                    }

                }
            }
            else if (token[index].ClassPart.Equals("MDM") ||
               token[index].ClassPart.Equals("PM") ||
               token[index].ClassPart.Equals("SO") ||
               token[index].ClassPart.Equals("ROP") ||
               token[index].ClassPart.Equals("&&") ||
               token[index].ClassPart.Equals("||") ||
               token[index].ClassPart.Equals("=") ||
               token[index].ClassPart.Equals(";") ||
               token[index].ClassPart.Equals(","))
            {
                return true;
            }
            return false;
        }
        public bool R11()
        {
            if (token[index].ClassPart.Equals("."))
                {
                index++;
                if (token[index].ClassPart.Equals("ID"))
                {
                    index++;
                    if (Z2())
                    {
                        return true;
                    }
                }
            }
            else if (token[index].ClassPart.Equals("["))
            {
                index++;
                if (token[index].ClassPart.Equals("int_const"))
                {
                    index++;
                    if (token[index].ClassPart.Equals("]"))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("."))
                        {
                            index++;
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (Z2())
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            else if (token[index].ClassPart.Equals("("))
            {
                index++;
                if (parameter())
                {
                    if (token[index].ClassPart.Equals(")"))
                    {
                        index++;
                        if (token[index].ClassPart.Equals("."))
                        {
                            index++;
                            if (token[index].ClassPart.Equals("ID"))
                            {
                                index++;
                                if (Z2())
                                {
                                    return true;
                                }

                            }
                        }
                    }

                }
            }
        
            else if (token[index].ClassPart.Equals("MDM") ||
                token[index].ClassPart.Equals("PM") ||
                token[index].ClassPart.Equals("SO") ||
                token[index].ClassPart.Equals("ROP") ||
                token[index].ClassPart.Equals("&&") ||
                token[index].ClassPart.Equals("||") ||
                token[index].ClassPart.Equals("=") ||
                token[index].ClassPart.Equals(";") ||
                token[index].ClassPart.Equals(","))
            {
                return true;
            }
            return false;
        }
    }
}
//STOPHERE