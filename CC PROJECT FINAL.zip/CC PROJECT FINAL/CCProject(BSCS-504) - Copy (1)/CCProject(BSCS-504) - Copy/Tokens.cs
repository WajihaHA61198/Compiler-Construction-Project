﻿using System;
using System.Text.RegularExpressions;

namespace CCProject_BSCS_504_
{
    class Tokens
    {
        string valuePart;
        string classPart;
        int line;

        //constructor
        public Tokens(string ValuePart, int Line)
        {
            valuePart = ValuePart;
            line = Line;
            classPart = identifyClass(ValuePart);
        }

        public string getData()
        {
            return "token=" + this.valuePart + " at line=" + this.line;
        }

        public string ClassPart { get { return classPart; } set { classPart = value; } }
        public string ValuePart { get { return valuePart; } set { valuePart = value; } }
        public int Line { get { return line; } set { line = value; } }

        string identifyClass(string value)
        {
            Regex idregex = new Regex(@"^[a-zA-Z][a-zA-Z0-9]*$");
            Regex intregex = new Regex(@"^[+-]?\d+$");
            Regex floatregex = new Regex(@"^[+-]?\d*[.]{1}\d+$");
            Regex stringregex1 = new Regex(@"^[""](\W|\w)*[""]$");
            Regex stringregex2 = new Regex(@"^[''](\W|\w)*['']$");


            string[,] keywords = new string[,] { {"int","data-type"}, {"float", "data-type" }, {"bool", "data-type" }, { "char", "data-type" }, { "string", "data-type" }, {"return","return"},{"this", "this"},{"switch","switch"},{"case","case"},{"default","default"},{"break","break"},{"continue","continue"},{"new","new"},{"void","void"},{"if","if"},{"else","else"},{"private","access-modifier"},{"public", "access-modifier" }, { "protected", "access-modifier" }, {"class","class"},{"main","main"},{"static","static"},{"abstract","abstract"},{"sealed","sealed"}, { "for", "for" }, { "do", "do"}, { "while", "while" }, {"interface","interface"} };

            string[,] operators = new string[,] { {"+","arithmetic-operator"}, {"-","arithmetic-operator"}, {"*","arithmetic-operator"}, {"/","arithmetic-operator"}, {"&&","logical-operator"}, {"||","logical-operator"}, {"!", "logical-operator" }, {"<","relational-operator"}, {">", "relational-operator" }, {"<=", "relational-operator" }, {">=", "relational-operator" }, {"!=", "relational-operator" },{"<<", "shift-operator" },{">>", "shift-operator" }, {"==", "relational-operator" },{"++","inc_dec"},{"--","inc_dec"},{"=","assignment-operator"}};
            
            string[,] punctuators = new string[,] { { "\"", "\"" }, { "'", "'" }, { "(", "(" }, { ")", ")" }, { "{", "{" }, { "}", "}" }, { "[", "[" }, { "]", "]" }, { ",", "," }, { ".", "." }, { ":", ":" }, { ";", ";" } };

            if (Char.IsLetter(value[0]))
            {
                for (int i = 0; i < keywords.Length / 2; i++)
                {
                    if (value == keywords[i, 0])
                        return keywords[i, 1];
                }

                if (idregex.IsMatch(value))
                return "ID";
            }

            else if (stringregex1.IsMatch(value) || stringregex2.IsMatch(value))
                return "string-const";
            else if (intregex.IsMatch(value))
                return "int-const";
            else if (floatregex.IsMatch(value))
                return "float-const";

            for (int i = 0; i < operators.Length / 2; i++)
            {
                if (value == operators[i, 0])
                    return operators[i, 1];
            }

            for (int i = 0; i < punctuators.Length / 2; i++)
            {
                if (value == punctuators[i, 0])
                    return punctuators[i, 1];
            }

            return "Invalid lexeme";
        }
    }
}