﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Text.RegularExpressions;
using System.Data;

namespace CCProject_BSCS_504_
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] token = new string[100, 2];
            List<Tokens> tk = new List<Tokens>();
            string temp = "";
            bool multiLineComment = false;
            int lineNum = 0;

            string[] text = File.ReadAllLines("SampleCode.txt");

          
            for (int i = 0; i < text.Length; i++)
            {
                string str = text[i];

                for (int j = 0; j < str.Length; j++)
                {
                    //SINGLE-LINE-COMMENT
                    if (str[j] == '/' && j + 1 < str.Length && str[j + 1] == '/')
                    {
                        break;
                    }

                    //MULTI-LINE-COMMENT
                    else if ((str[j] == '/' && j + 1 < str.Length && str[j + 1] == '*') || multiLineComment)
                    {
                        if (str[j] != '*' && j + 1 < str.Length && str[j + 1] != '/')
                        {
                            j++;
                            do
                            {
                                multiLineComment = true;
                                j++;
                            } while (str[j] != '*' && j + 1 < str.Length && str[j + 1] != '/');
                        }
                        //j = j + 2;
                        if (str[j] == '*' && str[j + 1] == '/')
                        {
                            j = j + 2;
                            multiLineComment = false;
                        }
                    }

                    //FOR STRING

                    if (str[j] == '\"' && multiLineComment != true)
                    {
                        temp += str[j];
                        while (j + 1 < str.Length && str[j + 1] != '\"')
                        {
                            if (str[j + 1] == '\\' && j + 2 < str.Length && (str[j + 2] == '\"'))
                            {
                                temp += str[j + 1].ToString() + str[j + 2].ToString();
                                j += 2;
                            }
                            else
                            {
                                j++;
                                temp += str[j];
                            }
                            if (j == str.Length - 1)
                                break;
                        }
                        if (j + 1 < str.Length && str[j + 1] == '\"')
                            temp += '\"';
                        j++;

                        tk.Add(new Tokens(temp, i));

                        temp = "";
                    }
                    else if (str[j] == '\'' && multiLineComment != true)
                    {
                        temp += str[j];
                        while (j + 1 < str.Length && str[j + 1] != '\'')
                        {
                            if (str[j + 1] == '\\' && j + 2 < str.Length && str[j + 2] == '\'')
                            {
                                temp += str[j + 1].ToString() + str[j + 2].ToString();
                                j += 2;
                            }

                            else
                            {
                                j++;
                                temp += str[j];
                            }
                            if (j == str.Length - 1)
                                break;
                        }
                        if (j + 1 < str.Length && (str[j + 1] == '\''))
                        {
                            temp += str[j + 1];
                        }
                        j++;

                        tk.Add(new Tokens(temp, i));

                        temp = "";
                    }

                    //FOR IDENTIFIER (done)
                    else if (Char.IsLetter(str[j]) && multiLineComment != true)
                    {
                        do
                        {
                            temp += str[j];
                            j++;
                            if (j == str.Length)
                            {
                                break;
                            }

                        } while (Char.IsLetter(str[j]) || Char.IsDigit(str[j]) || str[j] == '_' && str[j] != ' ');

                        tk.Add(new Tokens(temp, i));
                        temp = "";

                        j--;
                        lineNum++;
                    }

                    // FOR DIGITS
                    else if (multiLineComment != true && j < str.Length - 1 && (((str[j] == '+' || str[j] == '-') && (Char.IsDigit(str[j + 1]) || (str[j + 1] == '.' && Char.IsDigit(str[j + 2])))) || (str[j] == '.' && Char.IsDigit(str[j + 1])) || Char.IsDigit(str[j])) || (Char.IsDigit(str[j]) && str[j + 1] == '.'))
                    {
                        //if (multiLineComment != true && j < str.Length - 1 && (Char.IsDigit(str[j]) && str[j + 1] == '.'))
                        //{
                        //if (Char.IsLetter(str[j + 2]))
                        //{
                        //    temp += str[j];
                        //    j++;
                        //}
                        //}
                        do
                        {
                            if (str[j] == '.' && temp.Contains('.'))
                                break;

                            temp += str[j];
                            j++;
                            if (j == str.Length)
                                break;
                        } while (Char.IsDigit(str[j]) || str[j] == '.');

                        tk.Add(new Tokens(temp, i));

                        j--;
                        temp = "";
                        ++lineNum;
                    }
                    //else if (multiLineComment != true && j < str.Length - 1 && (Char.IsDigit(str[j]) && str[j + 1] == '.')) 
                    //{
                    //    if (Char.IsLetter(str[j+2]))
                    //    {
                    //        temp += str[j];
                    //        j++;
                    //    }

                    //    if (j == str.Length)
                    //    {
                    //        break;
                    //    }

                    //    tk.Add(new Tokens(temp, i));
                    //    temp = "";
                    //}


                    //FOR OPERATORS
                    else if (multiLineComment != true && j < str.Length && (str[j] == '+' || str[j] == '-' || str[j] == '*' || str[j] == '/' || str[j] == '%' || str[j] == '=' || str[j] == '<' || str[j] == '>' || str[j] == '^' || str[j] == '!' || str[j] == '&' || str[j] == '|')) // +-*/=%
                    {

                        temp += str[j];

                        if (j < str.Length - 1 && ((str[j] == '+' && str[j + 1] == '+') || (str[j] == '-' && str[j + 1] == '-') || (str[j] == '|' && str[j + 1] == '|') || (str[j] == '&' && str[j + 1] == '&'))) //++ -- && ||
                            temp += str[++j];
                        //else if (j < str.Length - 1 && ((str[j] == '|' && str[j + 1] == '=') || (str[j] == '&' && str[j + 1] == '=')))
                        //    temp += "";
                        else if (j < str.Length - 1 && str[j + 1] == '=')
                            temp += str[++j];
                        else if (j < str.Length - 1 && ((str[j] == '<' && str[j + 1] == '<') || (str[j] == '>' && str[j + 1] == '>')))
                            temp += str[++j];

                        tk.Add(new Tokens(temp, i));

                        temp = "";
                    }

                    // for + and -
                    else if (multiLineComment != true && j < str.Length && (str[j] == '+' || str[j] == '-'))
                    {
                        temp += str[j];

                        tk.Add(new Tokens(temp, i));

                        temp = "";
                    }

                    //FOR PUNCTUATOR
                    else if ((Char.IsPunctuation(str[j]) && str[j] != '#' && multiLineComment != true) || (multiLineComment != true && (str[j] == '`' || str[j] == '_' || str[j] == '~' || str[j] == '@' || str[j] == '\\' || str[j] == '$')))
                    {
                        tk.Add(new Tokens(str[j].ToString(), i));
                    }
                }
            }
           /* for (int i = 0; i < alToken.Count; i++)
            {
                Console.WriteLine((((Token)alToken[i])).getData());
            }*/

            tk.Add(new Tokens("$", -1));

            FileStream fs = new FileStream("Token.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine("Token => (ValuePart, ClassPart, Line Number)");
            foreach (var t in tk)
            {
                Console.WriteLine("({0},{1},{2})", t.ValuePart, t.ClassPart, t.Line);
                sw.WriteLine("({0},{1},{2})", t.ClassPart, t.ValuePart, t.Line);
            }
            sw.Flush();
            sw.Close();
            fs.Close();

            mapping_SyntaxAnalyzer_ obj = new mapping_SyntaxAnalyzer_(tk);
            Console.WriteLine($"check syntax: {obj.checkRule()}");
            Console.ReadLine();
            File.Create("Token.txt").Close();
        }
    }
}